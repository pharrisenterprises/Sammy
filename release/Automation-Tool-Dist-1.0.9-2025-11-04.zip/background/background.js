var si = Object.defineProperty;
var ci = (S, G, I) => G in S ? si(S, G, { enumerable: !0, configurable: !0, writable: !0, value: I }) : S[G] = I;
var Tn = (S, G, I) => ci(S, typeof G != "symbol" ? G + "" : G, I);
var li = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function fi(S) {
  return S && S.__esModule && Object.prototype.hasOwnProperty.call(S, "default") ? S.default : S;
}
var Ut = { exports: {} }, hi = Ut.exports, xr;
function di() {
  return xr || (xr = 1, function(S, G) {
    (function(I, D) {
      S.exports = D();
    })(hi, function() {
      var I = function(e, t) {
        return (I = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function(n, r) {
          n.__proto__ = r;
        } || function(n, r) {
          for (var i in r) Object.prototype.hasOwnProperty.call(r, i) && (n[i] = r[i]);
        })(e, t);
      }, D = function() {
        return (D = Object.assign || function(e) {
          for (var t, n = 1, r = arguments.length; n < r; n++) for (var i in t = arguments[n]) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
          return e;
        }).apply(this, arguments);
      };
      function Pe(e, t, n) {
        for (var r, i = 0, o = t.length; i < o; i++) !r && i in t || ((r = r || Array.prototype.slice.call(t, 0, i))[i] = t[i]);
        return e.concat(r || Array.prototype.slice.call(t));
      }
      var Q = typeof globalThis < "u" ? globalThis : typeof self < "u" ? self : typeof window < "u" ? window : li, q = Object.keys, A = Array.isArray;
      function V(e, t) {
        return typeof t != "object" || q(t).forEach(function(n) {
          e[n] = t[n];
        }), e;
      }
      typeof Promise > "u" || Q.Promise || (Q.Promise = Promise);
      var J = Object.getPrototypeOf, Pr = {}.hasOwnProperty;
      function re(e, t) {
        return Pr.call(e, t);
      }
      function Fe(e, t) {
        typeof t == "function" && (t = t(J(e))), (typeof Reflect > "u" ? q : Reflect.ownKeys)(t).forEach(function(n) {
          ve(e, n, t[n]);
        });
      }
      var qn = Object.defineProperty;
      function ve(e, t, n, r) {
        qn(e, t, V(n && re(n, "get") && typeof n.get == "function" ? { get: n.get, set: n.set, configurable: !0 } : { value: n, configurable: !0, writable: !0 }, r));
      }
      function Me(e) {
        return { from: function(t) {
          return e.prototype = Object.create(t.prototype), ve(e.prototype, "constructor", e), { extend: Fe.bind(null, e.prototype) };
        } };
      }
      var Or = Object.getOwnPropertyDescriptor, jr = [].slice;
      function dt(e, t, n) {
        return jr.call(e, t, n);
      }
      function Bn(e, t) {
        return t(e);
      }
      function Xe(e) {
        if (!e) throw new Error("Assertion Failed");
      }
      function Rn(e) {
        Q.setImmediate ? setImmediate(e) : setTimeout(e, 0);
      }
      function he(e, t) {
        if (typeof t == "string" && re(e, t)) return e[t];
        if (!t) return e;
        if (typeof t != "string") {
          for (var n = [], r = 0, i = t.length; r < i; ++r) {
            var o = he(e, t[r]);
            n.push(o);
          }
          return n;
        }
        var a = t.indexOf(".");
        if (a !== -1) {
          var u = e[t.substr(0, a)];
          return u == null ? void 0 : he(u, t.substr(a + 1));
        }
      }
      function ie(e, t, n) {
        if (e && t !== void 0 && !("isFrozen" in Object && Object.isFrozen(e))) if (typeof t != "string" && "length" in t) {
          Xe(typeof n != "string" && "length" in n);
          for (var r = 0, i = t.length; r < i; ++r) ie(e, t[r], n[r]);
        } else {
          var o, a, u = t.indexOf(".");
          u !== -1 ? (o = t.substr(0, u), (a = t.substr(u + 1)) === "" ? n === void 0 ? A(e) && !isNaN(parseInt(o)) ? e.splice(o, 1) : delete e[o] : e[o] = n : ie(u = !(u = e[o]) || !re(e, o) ? e[o] = {} : u, a, n)) : n === void 0 ? A(e) && !isNaN(parseInt(t)) ? e.splice(t, 1) : delete e[t] : e[t] = n;
        }
      }
      function Fn(e) {
        var t, n = {};
        for (t in e) re(e, t) && (n[t] = e[t]);
        return n;
      }
      var Er = [].concat;
      function Mn(e) {
        return Er.apply([], e);
      }
      var Ke = "BigUint64Array,BigInt64Array,Array,Boolean,String,Date,RegExp,Blob,File,FileList,FileSystemFileHandle,FileSystemDirectoryHandle,ArrayBuffer,DataView,Uint8ClampedArray,ImageBitmap,ImageData,Map,Set,CryptoKey".split(",").concat(Mn([8, 16, 32, 64].map(function(e) {
        return ["Int", "Uint", "Float"].map(function(t) {
          return t + e + "Array";
        });
      }))).filter(function(e) {
        return Q[e];
      }), Nn = new Set(Ke.map(function(e) {
        return Q[e];
      })), He = null;
      function Oe(e) {
        return He = /* @__PURE__ */ new WeakMap(), e = function t(n) {
          if (!n || typeof n != "object") return n;
          var r = He.get(n);
          if (r) return r;
          if (A(n)) {
            r = [], He.set(n, r);
            for (var i = 0, o = n.length; i < o; ++i) r.push(t(n[i]));
          } else if (Nn.has(n.constructor)) r = n;
          else {
            var a, u = J(n);
            for (a in r = u === Object.prototype ? {} : Object.create(u), He.set(n, r), n) re(n, a) && (r[a] = t(n[a]));
          }
          return r;
        }(e), He = null, e;
      }
      var Kr = {}.toString;
      function Yt(e) {
        return Kr.call(e).slice(8, -1);
      }
      var $t = typeof Symbol < "u" ? Symbol.iterator : "@@iterator", Sr = typeof $t == "symbol" ? function(e) {
        var t;
        return e != null && (t = e[$t]) && t.apply(e);
      } : function() {
        return null;
      };
      function je(e, t) {
        return t = e.indexOf(t), 0 <= t && e.splice(t, 1), 0 <= t;
      }
      var Ne = {};
      function de(e) {
        var t, n, r, i;
        if (arguments.length === 1) {
          if (A(e)) return e.slice();
          if (this === Ne && typeof e == "string") return [e];
          if (i = Sr(e)) {
            for (n = []; !(r = i.next()).done; ) n.push(r.value);
            return n;
          }
          if (e == null) return [e];
          if (typeof (t = e.length) != "number") return [e];
          for (n = new Array(t); t--; ) n[t] = e[t];
          return n;
        }
        for (t = arguments.length, n = new Array(t); t--; ) n[t] = arguments[t];
        return n;
      }
      var Qt = typeof Symbol < "u" ? function(e) {
        return e[Symbol.toStringTag] === "AsyncFunction";
      } : function() {
        return !1;
      }, et = ["Unknown", "Constraint", "Data", "TransactionInactive", "ReadOnly", "Version", "NotFound", "InvalidState", "InvalidAccess", "Abort", "Timeout", "QuotaExceeded", "Syntax", "DataClone"], se = ["Modify", "Bulk", "OpenFailed", "VersionChange", "Schema", "Upgrade", "InvalidTable", "MissingAPI", "NoSuchDatabase", "InvalidArgument", "SubTransaction", "Unsupported", "Internal", "DatabaseClosed", "PrematureCommit", "ForeignAwait"].concat(et), Ar = { VersionChanged: "Database version changed by other database connection", DatabaseClosed: "Database has been closed", Abort: "Transaction aborted", TransactionInactive: "Transaction has already completed or failed", MissingAPI: "IndexedDB API missing. Please visit https://tinyurl.com/y2uuvskb" };
      function Le(e, t) {
        this.name = e, this.message = t;
      }
      function Ln(e, t) {
        return e + ". Errors: " + Object.keys(t).map(function(n) {
          return t[n].toString();
        }).filter(function(n, r, i) {
          return i.indexOf(n) === r;
        }).join(`
`);
      }
      function pt(e, t, n, r) {
        this.failures = t, this.failedKeys = r, this.successCount = n, this.message = Ln(e, t);
      }
      function Ue(e, t) {
        this.name = "BulkError", this.failures = Object.keys(t).map(function(n) {
          return t[n];
        }), this.failuresByPos = t, this.message = Ln(e, this.failures);
      }
      Me(Le).from(Error).extend({ toString: function() {
        return this.name + ": " + this.message;
      } }), Me(pt).from(Le), Me(Ue).from(Le);
      var Gt = se.reduce(function(e, t) {
        return e[t] = t + "Error", e;
      }, {}), Cr = Le, T = se.reduce(function(e, t) {
        var n = t + "Error";
        function r(i, o) {
          this.name = n, i ? typeof i == "string" ? (this.message = "".concat(i).concat(o ? `
 ` + o : ""), this.inner = o || null) : typeof i == "object" && (this.message = "".concat(i.name, " ").concat(i.message), this.inner = i) : (this.message = Ar[t] || n, this.inner = null);
        }
        return Me(r).from(Cr), e[t] = r, e;
      }, {});
      T.Syntax = SyntaxError, T.Type = TypeError, T.Range = RangeError;
      var Un = et.reduce(function(e, t) {
        return e[t + "Error"] = T[t], e;
      }, {}), yt = se.reduce(function(e, t) {
        return ["Syntax", "Type", "Range"].indexOf(t) === -1 && (e[t + "Error"] = T[t]), e;
      }, {});
      function U() {
      }
      function Je(e) {
        return e;
      }
      function Ir(e, t) {
        return e == null || e === Je ? t : function(n) {
          return t(e(n));
        };
      }
      function Ee(e, t) {
        return function() {
          e.apply(this, arguments), t.apply(this, arguments);
        };
      }
      function Tr(e, t) {
        return e === U ? t : function() {
          var n = e.apply(this, arguments);
          n !== void 0 && (arguments[0] = n);
          var r = this.onsuccess, i = this.onerror;
          this.onsuccess = null, this.onerror = null;
          var o = t.apply(this, arguments);
          return r && (this.onsuccess = this.onsuccess ? Ee(r, this.onsuccess) : r), i && (this.onerror = this.onerror ? Ee(i, this.onerror) : i), o !== void 0 ? o : n;
        };
      }
      function Dr(e, t) {
        return e === U ? t : function() {
          e.apply(this, arguments);
          var n = this.onsuccess, r = this.onerror;
          this.onsuccess = this.onerror = null, t.apply(this, arguments), n && (this.onsuccess = this.onsuccess ? Ee(n, this.onsuccess) : n), r && (this.onerror = this.onerror ? Ee(r, this.onerror) : r);
        };
      }
      function qr(e, t) {
        return e === U ? t : function(n) {
          var r = e.apply(this, arguments);
          V(n, r);
          var i = this.onsuccess, o = this.onerror;
          return this.onsuccess = null, this.onerror = null, n = t.apply(this, arguments), i && (this.onsuccess = this.onsuccess ? Ee(i, this.onsuccess) : i), o && (this.onerror = this.onerror ? Ee(o, this.onerror) : o), r === void 0 ? n === void 0 ? void 0 : n : V(r, n);
        };
      }
      function Br(e, t) {
        return e === U ? t : function() {
          return t.apply(this, arguments) !== !1 && e.apply(this, arguments);
        };
      }
      function Xt(e, t) {
        return e === U ? t : function() {
          var n = e.apply(this, arguments);
          if (n && typeof n.then == "function") {
            for (var r = this, i = arguments.length, o = new Array(i); i--; ) o[i] = arguments[i];
            return n.then(function() {
              return t.apply(r, o);
            });
          }
          return t.apply(this, arguments);
        };
      }
      yt.ModifyError = pt, yt.DexieError = Le, yt.BulkError = Ue;
      var ce = typeof location < "u" && /^(http|https):\/\/(localhost|127\.0\.0\.1)/.test(location.href);
      function Vn(e) {
        ce = e;
      }
      var Ze = {}, zn = 100, Ke = typeof Promise > "u" ? [] : function() {
        var e = Promise.resolve();
        if (typeof crypto > "u" || !crypto.subtle) return [e, J(e), e];
        var t = crypto.subtle.digest("SHA-512", new Uint8Array([0]));
        return [t, J(t), e];
      }(), et = Ke[0], se = Ke[1], Ke = Ke[2], se = se && se.then, Se = et && et.constructor, Ht = !!Ke, tt = function(e, t) {
        nt.push([e, t]), vt && (queueMicrotask(Fr), vt = !1);
      }, Jt = !0, vt = !0, Ae = [], mt = [], Zt = Je, me = { id: "global", global: !0, ref: 0, unhandleds: [], onunhandled: U, pgp: !1, env: {}, finalize: U }, C = me, nt = [], Ce = 0, gt = [];
      function E(e) {
        if (typeof this != "object") throw new TypeError("Promises must be constructed via new");
        this._listeners = [], this._lib = !1;
        var t = this._PSD = C;
        if (typeof e != "function") {
          if (e !== Ze) throw new TypeError("Not a function");
          return this._state = arguments[1], this._value = arguments[2], void (this._state === !1 && tn(this, this._value));
        }
        this._state = null, this._value = null, ++t.ref, function n(r, i) {
          try {
            i(function(o) {
              if (r._state === null) {
                if (o === r) throw new TypeError("A promise cannot be resolved with itself.");
                var a = r._lib && Ve();
                o && typeof o.then == "function" ? n(r, function(u, c) {
                  o instanceof E ? o._then(u, c) : o.then(u, c);
                }) : (r._state = !0, r._value = o, Yn(r)), a && ze();
              }
            }, tn.bind(null, r));
          } catch (o) {
            tn(r, o);
          }
        }(this, e);
      }
      var en = { get: function() {
        var e = C, t = xt;
        function n(r, i) {
          var o = this, a = !e.global && (e !== C || t !== xt), u = a && !be(), c = new E(function(f, p) {
            nn(o, new Wn(Qn(r, e, a, u), Qn(i, e, a, u), f, p, e));
          });
          return this._consoleTask && (c._consoleTask = this._consoleTask), c;
        }
        return n.prototype = Ze, n;
      }, set: function(e) {
        ve(this, "then", e && e.prototype === Ze ? en : { get: function() {
          return e;
        }, set: en.set });
      } };
      function Wn(e, t, n, r, i) {
        this.onFulfilled = typeof e == "function" ? e : null, this.onRejected = typeof t == "function" ? t : null, this.resolve = n, this.reject = r, this.psd = i;
      }
      function tn(e, t) {
        var n, r;
        mt.push(t), e._state === null && (n = e._lib && Ve(), t = Zt(t), e._state = !1, e._value = t, r = e, Ae.some(function(i) {
          return i._value === r._value;
        }) || Ae.push(r), Yn(e), n && ze());
      }
      function Yn(e) {
        var t = e._listeners;
        e._listeners = [];
        for (var n = 0, r = t.length; n < r; ++n) nn(e, t[n]);
        var i = e._PSD;
        --i.ref || i.finalize(), Ce === 0 && (++Ce, tt(function() {
          --Ce == 0 && rn();
        }, []));
      }
      function nn(e, t) {
        if (e._state !== null) {
          var n = e._state ? t.onFulfilled : t.onRejected;
          if (n === null) return (e._state ? t.resolve : t.reject)(e._value);
          ++t.psd.ref, ++Ce, tt(Rr, [n, e, t]);
        } else e._listeners.push(t);
      }
      function Rr(e, t, n) {
        try {
          var r, i = t._value;
          !t._state && mt.length && (mt = []), r = ce && t._consoleTask ? t._consoleTask.run(function() {
            return e(i);
          }) : e(i), t._state || mt.indexOf(i) !== -1 || function(o) {
            for (var a = Ae.length; a; ) if (Ae[--a]._value === o._value) return Ae.splice(a, 1);
          }(t), n.resolve(r);
        } catch (o) {
          n.reject(o);
        } finally {
          --Ce == 0 && rn(), --n.psd.ref || n.psd.finalize();
        }
      }
      function Fr() {
        Ie(me, function() {
          Ve() && ze();
        });
      }
      function Ve() {
        var e = Jt;
        return vt = Jt = !1, e;
      }
      function ze() {
        var e, t, n;
        do
          for (; 0 < nt.length; ) for (e = nt, nt = [], n = e.length, t = 0; t < n; ++t) {
            var r = e[t];
            r[0].apply(null, r[1]);
          }
        while (0 < nt.length);
        vt = Jt = !0;
      }
      function rn() {
        var e = Ae;
        Ae = [], e.forEach(function(r) {
          r._PSD.onunhandled.call(null, r._value, r);
        });
        for (var t = gt.slice(0), n = t.length; n; ) t[--n]();
      }
      function bt(e) {
        return new E(Ze, !1, e);
      }
      function W(e, t) {
        var n = C;
        return function() {
          var r = Ve(), i = C;
          try {
            return we(n, !0), e.apply(this, arguments);
          } catch (o) {
            t && t(o);
          } finally {
            we(i, !1), r && ze();
          }
        };
      }
      Fe(E.prototype, { then: en, _then: function(e, t) {
        nn(this, new Wn(null, null, e, t, C));
      }, catch: function(e) {
        if (arguments.length === 1) return this.then(null, e);
        var t = e, n = arguments[1];
        return typeof t == "function" ? this.then(null, function(r) {
          return (r instanceof t ? n : bt)(r);
        }) : this.then(null, function(r) {
          return (r && r.name === t ? n : bt)(r);
        });
      }, finally: function(e) {
        return this.then(function(t) {
          return E.resolve(e()).then(function() {
            return t;
          });
        }, function(t) {
          return E.resolve(e()).then(function() {
            return bt(t);
          });
        });
      }, timeout: function(e, t) {
        var n = this;
        return e < 1 / 0 ? new E(function(r, i) {
          var o = setTimeout(function() {
            return i(new T.Timeout(t));
          }, e);
          n.then(r, i).finally(clearTimeout.bind(null, o));
        }) : this;
      } }), typeof Symbol < "u" && Symbol.toStringTag && ve(E.prototype, Symbol.toStringTag, "Dexie.Promise"), me.env = $n(), Fe(E, { all: function() {
        var e = de.apply(null, arguments).map(kt);
        return new E(function(t, n) {
          e.length === 0 && t([]);
          var r = e.length;
          e.forEach(function(i, o) {
            return E.resolve(i).then(function(a) {
              e[o] = a, --r || t(e);
            }, n);
          });
        });
      }, resolve: function(e) {
        return e instanceof E ? e : e && typeof e.then == "function" ? new E(function(t, n) {
          e.then(t, n);
        }) : new E(Ze, !0, e);
      }, reject: bt, race: function() {
        var e = de.apply(null, arguments).map(kt);
        return new E(function(t, n) {
          e.map(function(r) {
            return E.resolve(r).then(t, n);
          });
        });
      }, PSD: { get: function() {
        return C;
      }, set: function(e) {
        return C = e;
      } }, totalEchoes: { get: function() {
        return xt;
      } }, newPSD: ge, usePSD: Ie, scheduler: { get: function() {
        return tt;
      }, set: function(e) {
        tt = e;
      } }, rejectionMapper: { get: function() {
        return Zt;
      }, set: function(e) {
        Zt = e;
      } }, follow: function(e, t) {
        return new E(function(n, r) {
          return ge(function(i, o) {
            var a = C;
            a.unhandleds = [], a.onunhandled = o, a.finalize = Ee(function() {
              var u, c = this;
              u = function() {
                c.unhandleds.length === 0 ? i() : o(c.unhandleds[0]);
              }, gt.push(function f() {
                u(), gt.splice(gt.indexOf(f), 1);
              }), ++Ce, tt(function() {
                --Ce == 0 && rn();
              }, []);
            }, a.finalize), e();
          }, t, n, r);
        });
      } }), Se && (Se.allSettled && ve(E, "allSettled", function() {
        var e = de.apply(null, arguments).map(kt);
        return new E(function(t) {
          e.length === 0 && t([]);
          var n = e.length, r = new Array(n);
          e.forEach(function(i, o) {
            return E.resolve(i).then(function(a) {
              return r[o] = { status: "fulfilled", value: a };
            }, function(a) {
              return r[o] = { status: "rejected", reason: a };
            }).then(function() {
              return --n || t(r);
            });
          });
        });
      }), Se.any && typeof AggregateError < "u" && ve(E, "any", function() {
        var e = de.apply(null, arguments).map(kt);
        return new E(function(t, n) {
          e.length === 0 && n(new AggregateError([]));
          var r = e.length, i = new Array(r);
          e.forEach(function(o, a) {
            return E.resolve(o).then(function(u) {
              return t(u);
            }, function(u) {
              i[a] = u, --r || n(new AggregateError(i));
            });
          });
        });
      }), Se.withResolvers && (E.withResolvers = Se.withResolvers));
      var X = { awaits: 0, echoes: 0, id: 0 }, Mr = 0, wt = [], _t = 0, xt = 0, Nr = 0;
      function ge(e, t, n, r) {
        var i = C, o = Object.create(i);
        return o.parent = i, o.ref = 0, o.global = !1, o.id = ++Nr, me.env, o.env = Ht ? { Promise: E, PromiseProp: { value: E, configurable: !0, writable: !0 }, all: E.all, race: E.race, allSettled: E.allSettled, any: E.any, resolve: E.resolve, reject: E.reject } : {}, t && V(o, t), ++i.ref, o.finalize = function() {
          --this.parent.ref || this.parent.finalize();
        }, r = Ie(o, e, n, r), o.ref === 0 && o.finalize(), r;
      }
      function We() {
        return X.id || (X.id = ++Mr), ++X.awaits, X.echoes += zn, X.id;
      }
      function be() {
        return !!X.awaits && (--X.awaits == 0 && (X.id = 0), X.echoes = X.awaits * zn, !0);
      }
      function kt(e) {
        return X.echoes && e && e.constructor === Se ? (We(), e.then(function(t) {
          return be(), t;
        }, function(t) {
          return be(), Y(t);
        })) : e;
      }
      function Lr() {
        var e = wt[wt.length - 1];
        wt.pop(), we(e, !1);
      }
      function we(e, t) {
        var n, r = C;
        (t ? !X.echoes || _t++ && e === C : !_t || --_t && e === C) || queueMicrotask(t ? (function(i) {
          ++xt, X.echoes && --X.echoes != 0 || (X.echoes = X.awaits = X.id = 0), wt.push(C), we(i, !0);
        }).bind(null, e) : Lr), e !== C && (C = e, r === me && (me.env = $n()), Ht && (n = me.env.Promise, t = e.env, (r.global || e.global) && (Object.defineProperty(Q, "Promise", t.PromiseProp), n.all = t.all, n.race = t.race, n.resolve = t.resolve, n.reject = t.reject, t.allSettled && (n.allSettled = t.allSettled), t.any && (n.any = t.any))));
      }
      function $n() {
        var e = Q.Promise;
        return Ht ? { Promise: e, PromiseProp: Object.getOwnPropertyDescriptor(Q, "Promise"), all: e.all, race: e.race, allSettled: e.allSettled, any: e.any, resolve: e.resolve, reject: e.reject } : {};
      }
      function Ie(e, t, n, r, i) {
        var o = C;
        try {
          return we(e, !0), t(n, r, i);
        } finally {
          we(o, !1);
        }
      }
      function Qn(e, t, n, r) {
        return typeof e != "function" ? e : function() {
          var i = C;
          n && We(), we(t, !0);
          try {
            return e.apply(this, arguments);
          } finally {
            we(i, !1), r && queueMicrotask(be);
          }
        };
      }
      function on(e) {
        Promise === Se && X.echoes === 0 ? _t === 0 ? e() : enqueueNativeMicroTask(e) : setTimeout(e, 0);
      }
      ("" + se).indexOf("[native code]") === -1 && (We = be = U);
      var Y = E.reject, Te = "￿", pe = "Invalid key provided. Keys must be of type string, number, Date or Array<string | number | Date>.", Gn = "String expected.", Ye = [], Pt = "__dbnames", an = "readonly", un = "readwrite";
      function De(e, t) {
        return e ? t ? function() {
          return e.apply(this, arguments) && t.apply(this, arguments);
        } : e : t;
      }
      var Xn = { type: 3, lower: -1 / 0, lowerOpen: !1, upper: [[]], upperOpen: !1 };
      function Ot(e) {
        return typeof e != "string" || /\./.test(e) ? function(t) {
          return t;
        } : function(t) {
          return t[e] === void 0 && e in t && delete (t = Oe(t))[e], t;
        };
      }
      function Hn() {
        throw T.Type();
      }
      function N(e, t) {
        try {
          var n = Jn(e), r = Jn(t);
          if (n !== r) return n === "Array" ? 1 : r === "Array" ? -1 : n === "binary" ? 1 : r === "binary" ? -1 : n === "string" ? 1 : r === "string" ? -1 : n === "Date" ? 1 : r !== "Date" ? NaN : -1;
          switch (n) {
            case "number":
            case "Date":
            case "string":
              return t < e ? 1 : e < t ? -1 : 0;
            case "binary":
              return function(i, o) {
                for (var a = i.length, u = o.length, c = a < u ? a : u, f = 0; f < c; ++f) if (i[f] !== o[f]) return i[f] < o[f] ? -1 : 1;
                return a === u ? 0 : a < u ? -1 : 1;
              }(Zn(e), Zn(t));
            case "Array":
              return function(i, o) {
                for (var a = i.length, u = o.length, c = a < u ? a : u, f = 0; f < c; ++f) {
                  var p = N(i[f], o[f]);
                  if (p !== 0) return p;
                }
                return a === u ? 0 : a < u ? -1 : 1;
              }(e, t);
          }
        } catch {
        }
        return NaN;
      }
      function Jn(e) {
        var t = typeof e;
        return t != "object" ? t : ArrayBuffer.isView(e) ? "binary" : (e = Yt(e), e === "ArrayBuffer" ? "binary" : e);
      }
      function Zn(e) {
        return e instanceof Uint8Array ? e : ArrayBuffer.isView(e) ? new Uint8Array(e.buffer, e.byteOffset, e.byteLength) : new Uint8Array(e);
      }
      var er = (z.prototype._trans = function(e, t, n) {
        var r = this._tx || C.trans, i = this.name, o = ce && typeof console < "u" && console.createTask && console.createTask("Dexie: ".concat(e === "readonly" ? "read" : "write", " ").concat(this.name));
        function a(f, p, s) {
          if (!s.schema[i]) throw new T.NotFound("Table " + i + " not part of transaction");
          return t(s.idbtrans, s);
        }
        var u = Ve();
        try {
          var c = r && r.db._novip === this.db._novip ? r === C.trans ? r._promise(e, a, n) : ge(function() {
            return r._promise(e, a, n);
          }, { trans: r, transless: C.transless || C }) : function f(p, s, v, l) {
            if (p.idbdb && (p._state.openComplete || C.letThrough || p._vip)) {
              var d = p._createTransaction(s, v, p._dbSchema);
              try {
                d.create(), p._state.PR1398_maxLoop = 3;
              } catch (y) {
                return y.name === Gt.InvalidState && p.isOpen() && 0 < --p._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), p.close({ disableAutoOpen: !1 }), p.open().then(function() {
                  return f(p, s, v, l);
                })) : Y(y);
              }
              return d._promise(s, function(y, h) {
                return ge(function() {
                  return C.trans = d, l(y, h, d);
                });
              }).then(function(y) {
                if (s === "readwrite") try {
                  d.idbtrans.commit();
                } catch {
                }
                return s === "readonly" ? y : d._completion.then(function() {
                  return y;
                });
              });
            }
            if (p._state.openComplete) return Y(new T.DatabaseClosed(p._state.dbOpenError));
            if (!p._state.isBeingOpened) {
              if (!p._state.autoOpen) return Y(new T.DatabaseClosed());
              p.open().catch(U);
            }
            return p._state.dbReadyPromise.then(function() {
              return f(p, s, v, l);
            });
          }(this.db, e, [this.name], a);
          return o && (c._consoleTask = o, c = c.catch(function(f) {
            return console.trace(f), Y(f);
          })), c;
        } finally {
          u && ze();
        }
      }, z.prototype.get = function(e, t) {
        var n = this;
        return e && e.constructor === Object ? this.where(e).first(t) : e == null ? Y(new T.Type("Invalid argument to Table.get()")) : this._trans("readonly", function(r) {
          return n.core.get({ trans: r, key: e }).then(function(i) {
            return n.hook.reading.fire(i);
          });
        }).then(t);
      }, z.prototype.where = function(e) {
        if (typeof e == "string") return new this.db.WhereClause(this, e);
        if (A(e)) return new this.db.WhereClause(this, "[".concat(e.join("+"), "]"));
        var t = q(e);
        if (t.length === 1) return this.where(t[0]).equals(e[t[0]]);
        var n = this.schema.indexes.concat(this.schema.primKey).filter(function(u) {
          if (u.compound && t.every(function(f) {
            return 0 <= u.keyPath.indexOf(f);
          })) {
            for (var c = 0; c < t.length; ++c) if (t.indexOf(u.keyPath[c]) === -1) return !1;
            return !0;
          }
          return !1;
        }).sort(function(u, c) {
          return u.keyPath.length - c.keyPath.length;
        })[0];
        if (n && this.db._maxKey !== Te) {
          var o = n.keyPath.slice(0, t.length);
          return this.where(o).equals(o.map(function(c) {
            return e[c];
          }));
        }
        !n && ce && console.warn("The query ".concat(JSON.stringify(e), " on ").concat(this.name, " would benefit from a ") + "compound index [".concat(t.join("+"), "]"));
        var r = this.schema.idxByName;
        function i(u, c) {
          return N(u, c) === 0;
        }
        var a = t.reduce(function(s, c) {
          var f = s[0], p = s[1], s = r[c], v = e[c];
          return [f || s, f || !s ? De(p, s && s.multi ? function(l) {
            return l = he(l, c), A(l) && l.some(function(d) {
              return i(v, d);
            });
          } : function(l) {
            return i(v, he(l, c));
          }) : p];
        }, [null, null]), o = a[0], a = a[1];
        return o ? this.where(o.name).equals(e[o.keyPath]).filter(a) : n ? this.filter(a) : this.where(t).equals("");
      }, z.prototype.filter = function(e) {
        return this.toCollection().and(e);
      }, z.prototype.count = function(e) {
        return this.toCollection().count(e);
      }, z.prototype.offset = function(e) {
        return this.toCollection().offset(e);
      }, z.prototype.limit = function(e) {
        return this.toCollection().limit(e);
      }, z.prototype.each = function(e) {
        return this.toCollection().each(e);
      }, z.prototype.toArray = function(e) {
        return this.toCollection().toArray(e);
      }, z.prototype.toCollection = function() {
        return new this.db.Collection(new this.db.WhereClause(this));
      }, z.prototype.orderBy = function(e) {
        return new this.db.Collection(new this.db.WhereClause(this, A(e) ? "[".concat(e.join("+"), "]") : e));
      }, z.prototype.reverse = function() {
        return this.toCollection().reverse();
      }, z.prototype.mapToClass = function(e) {
        var t, n = this.db, r = this.name;
        function i() {
          return t !== null && t.apply(this, arguments) || this;
        }
        (this.schema.mappedClass = e).prototype instanceof Hn && (function(c, f) {
          if (typeof f != "function" && f !== null) throw new TypeError("Class extends value " + String(f) + " is not a constructor or null");
          function p() {
            this.constructor = c;
          }
          I(c, f), c.prototype = f === null ? Object.create(f) : (p.prototype = f.prototype, new p());
        }(i, t = e), Object.defineProperty(i.prototype, "db", { get: function() {
          return n;
        }, enumerable: !1, configurable: !0 }), i.prototype.table = function() {
          return r;
        }, e = i);
        for (var o = /* @__PURE__ */ new Set(), a = e.prototype; a; a = J(a)) Object.getOwnPropertyNames(a).forEach(function(c) {
          return o.add(c);
        });
        function u(c) {
          if (!c) return c;
          var f, p = Object.create(e.prototype);
          for (f in c) if (!o.has(f)) try {
            p[f] = c[f];
          } catch {
          }
          return p;
        }
        return this.schema.readHook && this.hook.reading.unsubscribe(this.schema.readHook), this.schema.readHook = u, this.hook("reading", u), e;
      }, z.prototype.defineClass = function() {
        return this.mapToClass(function(e) {
          V(this, e);
        });
      }, z.prototype.add = function(e, t) {
        var n = this, r = this.schema.primKey, i = r.auto, o = r.keyPath, a = e;
        return o && i && (a = Ot(o)(e)), this._trans("readwrite", function(u) {
          return n.core.mutate({ trans: u, type: "add", keys: t != null ? [t] : null, values: [a] });
        }).then(function(u) {
          return u.numFailures ? E.reject(u.failures[0]) : u.lastResult;
        }).then(function(u) {
          if (o) try {
            ie(e, o, u);
          } catch {
          }
          return u;
        });
      }, z.prototype.update = function(e, t) {
        return typeof e != "object" || A(e) ? this.where(":id").equals(e).modify(t) : (e = he(e, this.schema.primKey.keyPath), e === void 0 ? Y(new T.InvalidArgument("Given object does not contain its primary key")) : this.where(":id").equals(e).modify(t));
      }, z.prototype.put = function(e, t) {
        var n = this, r = this.schema.primKey, i = r.auto, o = r.keyPath, a = e;
        return o && i && (a = Ot(o)(e)), this._trans("readwrite", function(u) {
          return n.core.mutate({ trans: u, type: "put", values: [a], keys: t != null ? [t] : null });
        }).then(function(u) {
          return u.numFailures ? E.reject(u.failures[0]) : u.lastResult;
        }).then(function(u) {
          if (o) try {
            ie(e, o, u);
          } catch {
          }
          return u;
        });
      }, z.prototype.delete = function(e) {
        var t = this;
        return this._trans("readwrite", function(n) {
          return t.core.mutate({ trans: n, type: "delete", keys: [e] });
        }).then(function(n) {
          return n.numFailures ? E.reject(n.failures[0]) : void 0;
        });
      }, z.prototype.clear = function() {
        var e = this;
        return this._trans("readwrite", function(t) {
          return e.core.mutate({ trans: t, type: "deleteRange", range: Xn });
        }).then(function(t) {
          return t.numFailures ? E.reject(t.failures[0]) : void 0;
        });
      }, z.prototype.bulkGet = function(e) {
        var t = this;
        return this._trans("readonly", function(n) {
          return t.core.getMany({ keys: e, trans: n }).then(function(r) {
            return r.map(function(i) {
              return t.hook.reading.fire(i);
            });
          });
        });
      }, z.prototype.bulkAdd = function(e, t, n) {
        var r = this, i = Array.isArray(t) ? t : void 0, o = (n = n || (i ? void 0 : t)) ? n.allKeys : void 0;
        return this._trans("readwrite", function(a) {
          var f = r.schema.primKey, u = f.auto, f = f.keyPath;
          if (f && i) throw new T.InvalidArgument("bulkAdd(): keys argument invalid on tables with inbound keys");
          if (i && i.length !== e.length) throw new T.InvalidArgument("Arguments objects and keys must have the same length");
          var c = e.length, f = f && u ? e.map(Ot(f)) : e;
          return r.core.mutate({ trans: a, type: "add", keys: i, values: f, wantResults: o }).then(function(d) {
            var s = d.numFailures, v = d.results, l = d.lastResult, d = d.failures;
            if (s === 0) return o ? v : l;
            throw new Ue("".concat(r.name, ".bulkAdd(): ").concat(s, " of ").concat(c, " operations failed"), d);
          });
        });
      }, z.prototype.bulkPut = function(e, t, n) {
        var r = this, i = Array.isArray(t) ? t : void 0, o = (n = n || (i ? void 0 : t)) ? n.allKeys : void 0;
        return this._trans("readwrite", function(a) {
          var f = r.schema.primKey, u = f.auto, f = f.keyPath;
          if (f && i) throw new T.InvalidArgument("bulkPut(): keys argument invalid on tables with inbound keys");
          if (i && i.length !== e.length) throw new T.InvalidArgument("Arguments objects and keys must have the same length");
          var c = e.length, f = f && u ? e.map(Ot(f)) : e;
          return r.core.mutate({ trans: a, type: "put", keys: i, values: f, wantResults: o }).then(function(d) {
            var s = d.numFailures, v = d.results, l = d.lastResult, d = d.failures;
            if (s === 0) return o ? v : l;
            throw new Ue("".concat(r.name, ".bulkPut(): ").concat(s, " of ").concat(c, " operations failed"), d);
          });
        });
      }, z.prototype.bulkUpdate = function(e) {
        var t = this, n = this.core, r = e.map(function(a) {
          return a.key;
        }), i = e.map(function(a) {
          return a.changes;
        }), o = [];
        return this._trans("readwrite", function(a) {
          return n.getMany({ trans: a, keys: r, cache: "clone" }).then(function(u) {
            var c = [], f = [];
            e.forEach(function(s, v) {
              var l = s.key, d = s.changes, y = u[v];
              if (y) {
                for (var h = 0, m = Object.keys(d); h < m.length; h++) {
                  var g = m[h], b = d[g];
                  if (g === t.schema.primKey.keyPath) {
                    if (N(b, l) !== 0) throw new T.Constraint("Cannot update primary key in bulkUpdate()");
                  } else ie(y, g, b);
                }
                o.push(v), c.push(l), f.push(y);
              }
            });
            var p = c.length;
            return n.mutate({ trans: a, type: "put", keys: c, values: f, updates: { keys: r, changeSpecs: i } }).then(function(s) {
              var v = s.numFailures, l = s.failures;
              if (v === 0) return p;
              for (var d = 0, y = Object.keys(l); d < y.length; d++) {
                var h, m = y[d], g = o[Number(m)];
                g != null && (h = l[m], delete l[m], l[g] = h);
              }
              throw new Ue("".concat(t.name, ".bulkUpdate(): ").concat(v, " of ").concat(p, " operations failed"), l);
            });
          });
        });
      }, z.prototype.bulkDelete = function(e) {
        var t = this, n = e.length;
        return this._trans("readwrite", function(r) {
          return t.core.mutate({ trans: r, type: "delete", keys: e });
        }).then(function(a) {
          var i = a.numFailures, o = a.lastResult, a = a.failures;
          if (i === 0) return o;
          throw new Ue("".concat(t.name, ".bulkDelete(): ").concat(i, " of ").concat(n, " operations failed"), a);
        });
      }, z);
      function z() {
      }
      function rt(e) {
        function t(a, u) {
          if (u) {
            for (var c = arguments.length, f = new Array(c - 1); --c; ) f[c - 1] = arguments[c];
            return n[a].subscribe.apply(null, f), e;
          }
          if (typeof a == "string") return n[a];
        }
        var n = {};
        t.addEventType = o;
        for (var r = 1, i = arguments.length; r < i; ++r) o(arguments[r]);
        return t;
        function o(a, u, c) {
          if (typeof a != "object") {
            var f;
            u = u || Br;
            var p = { subscribers: [], fire: c = c || U, subscribe: function(s) {
              p.subscribers.indexOf(s) === -1 && (p.subscribers.push(s), p.fire = u(p.fire, s));
            }, unsubscribe: function(s) {
              p.subscribers = p.subscribers.filter(function(v) {
                return v !== s;
              }), p.fire = p.subscribers.reduce(u, c);
            } };
            return n[a] = t[a] = p;
          }
          q(f = a).forEach(function(s) {
            var v = f[s];
            if (A(v)) o(s, f[s][0], f[s][1]);
            else {
              if (v !== "asap") throw new T.InvalidArgument("Invalid event config");
              var l = o(s, Je, function() {
                for (var d = arguments.length, y = new Array(d); d--; ) y[d] = arguments[d];
                l.subscribers.forEach(function(h) {
                  Rn(function() {
                    h.apply(null, y);
                  });
                });
              });
            }
          });
        }
      }
      function it(e, t) {
        return Me(t).from({ prototype: e }), t;
      }
      function $e(e, t) {
        return !(e.filter || e.algorithm || e.or) && (t ? e.justLimit : !e.replayFilter);
      }
      function sn(e, t) {
        e.filter = De(e.filter, t);
      }
      function cn(e, t, n) {
        var r = e.replayFilter;
        e.replayFilter = r ? function() {
          return De(r(), t());
        } : t, e.justLimit = n && !r;
      }
      function jt(e, t) {
        if (e.isPrimKey) return t.primaryKey;
        var n = t.getIndexByKeyPath(e.index);
        if (!n) throw new T.Schema("KeyPath " + e.index + " on object store " + t.name + " is not indexed");
        return n;
      }
      function tr(e, t, n) {
        var r = jt(e, t.schema);
        return t.openCursor({ trans: n, values: !e.keysOnly, reverse: e.dir === "prev", unique: !!e.unique, query: { index: r, range: e.range } });
      }
      function Et(e, t, n, r) {
        var i = e.replayFilter ? De(e.filter, e.replayFilter()) : e.filter;
        if (e.or) {
          var o = {}, a = function(u, c, f) {
            var p, s;
            i && !i(c, f, function(v) {
              return c.stop(v);
            }, function(v) {
              return c.fail(v);
            }) || ((s = "" + (p = c.primaryKey)) == "[object ArrayBuffer]" && (s = "" + new Uint8Array(p)), re(o, s) || (o[s] = !0, t(u, c, f)));
          };
          return Promise.all([e.or._iterate(a, n), nr(tr(e, r, n), e.algorithm, a, !e.keysOnly && e.valueMapper)]);
        }
        return nr(tr(e, r, n), De(e.algorithm, i), t, !e.keysOnly && e.valueMapper);
      }
      function nr(e, t, n, r) {
        var i = W(r ? function(o, a, u) {
          return n(r(o), a, u);
        } : n);
        return e.then(function(o) {
          if (o) return o.start(function() {
            var a = function() {
              return o.continue();
            };
            t && !t(o, function(u) {
              return a = u;
            }, function(u) {
              o.stop(u), a = U;
            }, function(u) {
              o.fail(u), a = U;
            }) || i(o.value, o, function(u) {
              return a = u;
            }), a();
          });
        });
      }
      var ot = (rr.prototype.execute = function(e) {
        var t = this["@@propmod"];
        if (t.add !== void 0) {
          var n = t.add;
          if (A(n)) return Pe(Pe([], A(e) ? e : [], !0), n).sort();
          if (typeof n == "number") return (Number(e) || 0) + n;
          if (typeof n == "bigint") try {
            return BigInt(e) + n;
          } catch {
            return BigInt(0) + n;
          }
          throw new TypeError("Invalid term ".concat(n));
        }
        if (t.remove !== void 0) {
          var r = t.remove;
          if (A(r)) return A(e) ? e.filter(function(i) {
            return !r.includes(i);
          }).sort() : [];
          if (typeof r == "number") return Number(e) - r;
          if (typeof r == "bigint") try {
            return BigInt(e) - r;
          } catch {
            return BigInt(0) - r;
          }
          throw new TypeError("Invalid subtrahend ".concat(r));
        }
        return n = (n = t.replacePrefix) === null || n === void 0 ? void 0 : n[0], n && typeof e == "string" && e.startsWith(n) ? t.replacePrefix[1] + e.substring(n.length) : e;
      }, rr);
      function rr(e) {
        this["@@propmod"] = e;
      }
      var Ur = (L.prototype._read = function(e, t) {
        var n = this._ctx;
        return n.error ? n.table._trans(null, Y.bind(null, n.error)) : n.table._trans("readonly", e).then(t);
      }, L.prototype._write = function(e) {
        var t = this._ctx;
        return t.error ? t.table._trans(null, Y.bind(null, t.error)) : t.table._trans("readwrite", e, "locked");
      }, L.prototype._addAlgorithm = function(e) {
        var t = this._ctx;
        t.algorithm = De(t.algorithm, e);
      }, L.prototype._iterate = function(e, t) {
        return Et(this._ctx, e, t, this._ctx.table.core);
      }, L.prototype.clone = function(e) {
        var t = Object.create(this.constructor.prototype), n = Object.create(this._ctx);
        return e && V(n, e), t._ctx = n, t;
      }, L.prototype.raw = function() {
        return this._ctx.valueMapper = null, this;
      }, L.prototype.each = function(e) {
        var t = this._ctx;
        return this._read(function(n) {
          return Et(t, e, n, t.table.core);
        });
      }, L.prototype.count = function(e) {
        var t = this;
        return this._read(function(n) {
          var r = t._ctx, i = r.table.core;
          if ($e(r, !0)) return i.count({ trans: n, query: { index: jt(r, i.schema), range: r.range } }).then(function(a) {
            return Math.min(a, r.limit);
          });
          var o = 0;
          return Et(r, function() {
            return ++o, !1;
          }, n, i).then(function() {
            return o;
          });
        }).then(e);
      }, L.prototype.sortBy = function(e, t) {
        var n = e.split(".").reverse(), r = n[0], i = n.length - 1;
        function o(c, f) {
          return f ? o(c[n[f]], f - 1) : c[r];
        }
        var a = this._ctx.dir === "next" ? 1 : -1;
        function u(c, f) {
          return N(o(c, i), o(f, i)) * a;
        }
        return this.toArray(function(c) {
          return c.sort(u);
        }).then(t);
      }, L.prototype.toArray = function(e) {
        var t = this;
        return this._read(function(n) {
          var r = t._ctx;
          if (r.dir === "next" && $e(r, !0) && 0 < r.limit) {
            var i = r.valueMapper, o = jt(r, r.table.core.schema);
            return r.table.core.query({ trans: n, limit: r.limit, values: !0, query: { index: o, range: r.range } }).then(function(u) {
              return u = u.result, i ? u.map(i) : u;
            });
          }
          var a = [];
          return Et(r, function(u) {
            return a.push(u);
          }, n, r.table.core).then(function() {
            return a;
          });
        }, e);
      }, L.prototype.offset = function(e) {
        var t = this._ctx;
        return e <= 0 || (t.offset += e, $e(t) ? cn(t, function() {
          var n = e;
          return function(r, i) {
            return n === 0 || (n === 1 ? --n : i(function() {
              r.advance(n), n = 0;
            }), !1);
          };
        }) : cn(t, function() {
          var n = e;
          return function() {
            return --n < 0;
          };
        })), this;
      }, L.prototype.limit = function(e) {
        return this._ctx.limit = Math.min(this._ctx.limit, e), cn(this._ctx, function() {
          var t = e;
          return function(n, r, i) {
            return --t <= 0 && r(i), 0 <= t;
          };
        }, !0), this;
      }, L.prototype.until = function(e, t) {
        return sn(this._ctx, function(n, r, i) {
          return !e(n.value) || (r(i), t);
        }), this;
      }, L.prototype.first = function(e) {
        return this.limit(1).toArray(function(t) {
          return t[0];
        }).then(e);
      }, L.prototype.last = function(e) {
        return this.reverse().first(e);
      }, L.prototype.filter = function(e) {
        var t;
        return sn(this._ctx, function(n) {
          return e(n.value);
        }), (t = this._ctx).isMatch = De(t.isMatch, e), this;
      }, L.prototype.and = function(e) {
        return this.filter(e);
      }, L.prototype.or = function(e) {
        return new this.db.WhereClause(this._ctx.table, e, this);
      }, L.prototype.reverse = function() {
        return this._ctx.dir = this._ctx.dir === "prev" ? "next" : "prev", this._ondirectionchange && this._ondirectionchange(this._ctx.dir), this;
      }, L.prototype.desc = function() {
        return this.reverse();
      }, L.prototype.eachKey = function(e) {
        var t = this._ctx;
        return t.keysOnly = !t.isMatch, this.each(function(n, r) {
          e(r.key, r);
        });
      }, L.prototype.eachUniqueKey = function(e) {
        return this._ctx.unique = "unique", this.eachKey(e);
      }, L.prototype.eachPrimaryKey = function(e) {
        var t = this._ctx;
        return t.keysOnly = !t.isMatch, this.each(function(n, r) {
          e(r.primaryKey, r);
        });
      }, L.prototype.keys = function(e) {
        var t = this._ctx;
        t.keysOnly = !t.isMatch;
        var n = [];
        return this.each(function(r, i) {
          n.push(i.key);
        }).then(function() {
          return n;
        }).then(e);
      }, L.prototype.primaryKeys = function(e) {
        var t = this._ctx;
        if (t.dir === "next" && $e(t, !0) && 0 < t.limit) return this._read(function(r) {
          var i = jt(t, t.table.core.schema);
          return t.table.core.query({ trans: r, values: !1, limit: t.limit, query: { index: i, range: t.range } });
        }).then(function(r) {
          return r.result;
        }).then(e);
        t.keysOnly = !t.isMatch;
        var n = [];
        return this.each(function(r, i) {
          n.push(i.primaryKey);
        }).then(function() {
          return n;
        }).then(e);
      }, L.prototype.uniqueKeys = function(e) {
        return this._ctx.unique = "unique", this.keys(e);
      }, L.prototype.firstKey = function(e) {
        return this.limit(1).keys(function(t) {
          return t[0];
        }).then(e);
      }, L.prototype.lastKey = function(e) {
        return this.reverse().firstKey(e);
      }, L.prototype.distinct = function() {
        var e = this._ctx, e = e.index && e.table.schema.idxByName[e.index];
        if (!e || !e.multi) return this;
        var t = {};
        return sn(this._ctx, function(i) {
          var r = i.primaryKey.toString(), i = re(t, r);
          return t[r] = !0, !i;
        }), this;
      }, L.prototype.modify = function(e) {
        var t = this, n = this._ctx;
        return this._write(function(r) {
          var i, o, a;
          a = typeof e == "function" ? e : (i = q(e), o = i.length, function(h) {
            for (var m = !1, g = 0; g < o; ++g) {
              var b = i[g], w = e[b], _ = he(h, b);
              w instanceof ot ? (ie(h, b, w.execute(_)), m = !0) : _ !== w && (ie(h, b, w), m = !0);
            }
            return m;
          });
          var u = n.table.core, s = u.schema.primaryKey, c = s.outbound, f = s.extractKey, p = 200, s = t.db._options.modifyChunkSize;
          s && (p = typeof s == "object" ? s[u.name] || s["*"] || 200 : s);
          function v(h, b) {
            var g = b.failures, b = b.numFailures;
            d += h - b;
            for (var w = 0, _ = q(g); w < _.length; w++) {
              var O = _[w];
              l.push(g[O]);
            }
          }
          var l = [], d = 0, y = [];
          return t.clone().primaryKeys().then(function(h) {
            function m(b) {
              var w = Math.min(p, h.length - b);
              return u.getMany({ trans: r, keys: h.slice(b, b + w), cache: "immutable" }).then(function(_) {
                for (var O = [], x = [], k = c ? [] : null, j = [], P = 0; P < w; ++P) {
                  var K = _[P], R = { value: Oe(K), primKey: h[b + P] };
                  a.call(R, R.value, R) !== !1 && (R.value == null ? j.push(h[b + P]) : c || N(f(K), f(R.value)) === 0 ? (x.push(R.value), c && k.push(h[b + P])) : (j.push(h[b + P]), O.push(R.value)));
                }
                return Promise.resolve(0 < O.length && u.mutate({ trans: r, type: "add", values: O }).then(function(F) {
                  for (var M in F.failures) j.splice(parseInt(M), 1);
                  v(O.length, F);
                })).then(function() {
                  return (0 < x.length || g && typeof e == "object") && u.mutate({ trans: r, type: "put", keys: k, values: x, criteria: g, changeSpec: typeof e != "function" && e, isAdditionalChunk: 0 < b }).then(function(F) {
                    return v(x.length, F);
                  });
                }).then(function() {
                  return (0 < j.length || g && e === ln) && u.mutate({ trans: r, type: "delete", keys: j, criteria: g, isAdditionalChunk: 0 < b }).then(function(F) {
                    return v(j.length, F);
                  });
                }).then(function() {
                  return h.length > b + w && m(b + p);
                });
              });
            }
            var g = $e(n) && n.limit === 1 / 0 && (typeof e != "function" || e === ln) && { index: n.index, range: n.range };
            return m(0).then(function() {
              if (0 < l.length) throw new pt("Error modifying one or more objects", l, d, y);
              return h.length;
            });
          });
        });
      }, L.prototype.delete = function() {
        var e = this._ctx, t = e.range;
        return $e(e) && (e.isPrimKey || t.type === 3) ? this._write(function(n) {
          var r = e.table.core.schema.primaryKey, i = t;
          return e.table.core.count({ trans: n, query: { index: r, range: i } }).then(function(o) {
            return e.table.core.mutate({ trans: n, type: "deleteRange", range: i }).then(function(a) {
              var u = a.failures;
              if (a.lastResult, a.results, a = a.numFailures, a) throw new pt("Could not delete some values", Object.keys(u).map(function(c) {
                return u[c];
              }), o - a);
              return o - a;
            });
          });
        }) : this.modify(ln);
      }, L);
      function L() {
      }
      var ln = function(e, t) {
        return t.value = null;
      };
      function Vr(e, t) {
        return e < t ? -1 : e === t ? 0 : 1;
      }
      function zr(e, t) {
        return t < e ? -1 : e === t ? 0 : 1;
      }
      function oe(e, t, n) {
        return e = e instanceof or ? new e.Collection(e) : e, e._ctx.error = new (n || TypeError)(t), e;
      }
      function Qe(e) {
        return new e.Collection(e, function() {
          return ir("");
        }).limit(0);
      }
      function Kt(e, t, n, r) {
        var i, o, a, u, c, f, p, s = n.length;
        if (!n.every(function(d) {
          return typeof d == "string";
        })) return oe(e, Gn);
        function v(d) {
          i = d === "next" ? function(h) {
            return h.toUpperCase();
          } : function(h) {
            return h.toLowerCase();
          }, o = d === "next" ? function(h) {
            return h.toLowerCase();
          } : function(h) {
            return h.toUpperCase();
          }, a = d === "next" ? Vr : zr;
          var y = n.map(function(h) {
            return { lower: o(h), upper: i(h) };
          }).sort(function(h, m) {
            return a(h.lower, m.lower);
          });
          u = y.map(function(h) {
            return h.upper;
          }), c = y.map(function(h) {
            return h.lower;
          }), p = (f = d) === "next" ? "" : r;
        }
        v("next"), e = new e.Collection(e, function() {
          return _e(u[0], c[s - 1] + r);
        }), e._ondirectionchange = function(d) {
          v(d);
        };
        var l = 0;
        return e._addAlgorithm(function(d, y, h) {
          var m = d.key;
          if (typeof m != "string") return !1;
          var g = o(m);
          if (t(g, c, l)) return !0;
          for (var b = null, w = l; w < s; ++w) {
            var _ = function(O, x, k, j, P, K) {
              for (var R = Math.min(O.length, j.length), F = -1, M = 0; M < R; ++M) {
                var ae = x[M];
                if (ae !== j[M]) return P(O[M], k[M]) < 0 ? O.substr(0, M) + k[M] + k.substr(M + 1) : P(O[M], j[M]) < 0 ? O.substr(0, M) + j[M] + k.substr(M + 1) : 0 <= F ? O.substr(0, F) + x[F] + k.substr(F + 1) : null;
                P(O[M], ae) < 0 && (F = M);
              }
              return R < j.length && K === "next" ? O + k.substr(O.length) : R < O.length && K === "prev" ? O.substr(0, k.length) : F < 0 ? null : O.substr(0, F) + j[F] + k.substr(F + 1);
            }(m, g, u[w], c[w], a, f);
            _ === null && b === null ? l = w + 1 : (b === null || 0 < a(b, _)) && (b = _);
          }
          return y(b !== null ? function() {
            d.continue(b + p);
          } : h), !1;
        }), e;
      }
      function _e(e, t, n, r) {
        return { type: 2, lower: e, upper: t, lowerOpen: n, upperOpen: r };
      }
      function ir(e) {
        return { type: 1, lower: e, upper: e };
      }
      var or = (Object.defineProperty(H.prototype, "Collection", { get: function() {
        return this._ctx.table.db.Collection;
      }, enumerable: !1, configurable: !0 }), H.prototype.between = function(e, t, n, r) {
        n = n !== !1, r = r === !0;
        try {
          return 0 < this._cmp(e, t) || this._cmp(e, t) === 0 && (n || r) && (!n || !r) ? Qe(this) : new this.Collection(this, function() {
            return _e(e, t, !n, !r);
          });
        } catch {
          return oe(this, pe);
        }
      }, H.prototype.equals = function(e) {
        return e == null ? oe(this, pe) : new this.Collection(this, function() {
          return ir(e);
        });
      }, H.prototype.above = function(e) {
        return e == null ? oe(this, pe) : new this.Collection(this, function() {
          return _e(e, void 0, !0);
        });
      }, H.prototype.aboveOrEqual = function(e) {
        return e == null ? oe(this, pe) : new this.Collection(this, function() {
          return _e(e, void 0, !1);
        });
      }, H.prototype.below = function(e) {
        return e == null ? oe(this, pe) : new this.Collection(this, function() {
          return _e(void 0, e, !1, !0);
        });
      }, H.prototype.belowOrEqual = function(e) {
        return e == null ? oe(this, pe) : new this.Collection(this, function() {
          return _e(void 0, e);
        });
      }, H.prototype.startsWith = function(e) {
        return typeof e != "string" ? oe(this, Gn) : this.between(e, e + Te, !0, !0);
      }, H.prototype.startsWithIgnoreCase = function(e) {
        return e === "" ? this.startsWith(e) : Kt(this, function(t, n) {
          return t.indexOf(n[0]) === 0;
        }, [e], Te);
      }, H.prototype.equalsIgnoreCase = function(e) {
        return Kt(this, function(t, n) {
          return t === n[0];
        }, [e], "");
      }, H.prototype.anyOfIgnoreCase = function() {
        var e = de.apply(Ne, arguments);
        return e.length === 0 ? Qe(this) : Kt(this, function(t, n) {
          return n.indexOf(t) !== -1;
        }, e, "");
      }, H.prototype.startsWithAnyOfIgnoreCase = function() {
        var e = de.apply(Ne, arguments);
        return e.length === 0 ? Qe(this) : Kt(this, function(t, n) {
          return n.some(function(r) {
            return t.indexOf(r) === 0;
          });
        }, e, Te);
      }, H.prototype.anyOf = function() {
        var e = this, t = de.apply(Ne, arguments), n = this._cmp;
        try {
          t.sort(n);
        } catch {
          return oe(this, pe);
        }
        if (t.length === 0) return Qe(this);
        var r = new this.Collection(this, function() {
          return _e(t[0], t[t.length - 1]);
        });
        r._ondirectionchange = function(o) {
          n = o === "next" ? e._ascending : e._descending, t.sort(n);
        };
        var i = 0;
        return r._addAlgorithm(function(o, a, u) {
          for (var c = o.key; 0 < n(c, t[i]); ) if (++i === t.length) return a(u), !1;
          return n(c, t[i]) === 0 || (a(function() {
            o.continue(t[i]);
          }), !1);
        }), r;
      }, H.prototype.notEqual = function(e) {
        return this.inAnyRange([[-1 / 0, e], [e, this.db._maxKey]], { includeLowers: !1, includeUppers: !1 });
      }, H.prototype.noneOf = function() {
        var e = de.apply(Ne, arguments);
        if (e.length === 0) return new this.Collection(this);
        try {
          e.sort(this._ascending);
        } catch {
          return oe(this, pe);
        }
        var t = e.reduce(function(n, r) {
          return n ? n.concat([[n[n.length - 1][1], r]]) : [[-1 / 0, r]];
        }, null);
        return t.push([e[e.length - 1], this.db._maxKey]), this.inAnyRange(t, { includeLowers: !1, includeUppers: !1 });
      }, H.prototype.inAnyRange = function(m, t) {
        var n = this, r = this._cmp, i = this._ascending, o = this._descending, a = this._min, u = this._max;
        if (m.length === 0) return Qe(this);
        if (!m.every(function(g) {
          return g[0] !== void 0 && g[1] !== void 0 && i(g[0], g[1]) <= 0;
        })) return oe(this, "First argument to inAnyRange() must be an Array of two-value Arrays [lower,upper] where upper must not be lower than lower", T.InvalidArgument);
        var c = !t || t.includeLowers !== !1, f = t && t.includeUppers === !0, p, s = i;
        function v(g, b) {
          return s(g[0], b[0]);
        }
        try {
          (p = m.reduce(function(g, b) {
            for (var w = 0, _ = g.length; w < _; ++w) {
              var O = g[w];
              if (r(b[0], O[1]) < 0 && 0 < r(b[1], O[0])) {
                O[0] = a(O[0], b[0]), O[1] = u(O[1], b[1]);
                break;
              }
            }
            return w === _ && g.push(b), g;
          }, [])).sort(v);
        } catch {
          return oe(this, pe);
        }
        var l = 0, d = f ? function(g) {
          return 0 < i(g, p[l][1]);
        } : function(g) {
          return 0 <= i(g, p[l][1]);
        }, y = c ? function(g) {
          return 0 < o(g, p[l][0]);
        } : function(g) {
          return 0 <= o(g, p[l][0]);
        }, h = d, m = new this.Collection(this, function() {
          return _e(p[0][0], p[p.length - 1][1], !c, !f);
        });
        return m._ondirectionchange = function(g) {
          s = g === "next" ? (h = d, i) : (h = y, o), p.sort(v);
        }, m._addAlgorithm(function(g, b, w) {
          for (var _, O = g.key; h(O); ) if (++l === p.length) return b(w), !1;
          return !d(_ = O) && !y(_) || (n._cmp(O, p[l][1]) === 0 || n._cmp(O, p[l][0]) === 0 || b(function() {
            s === i ? g.continue(p[l][0]) : g.continue(p[l][1]);
          }), !1);
        }), m;
      }, H.prototype.startsWithAnyOf = function() {
        var e = de.apply(Ne, arguments);
        return e.every(function(t) {
          return typeof t == "string";
        }) ? e.length === 0 ? Qe(this) : this.inAnyRange(e.map(function(t) {
          return [t, t + Te];
        })) : oe(this, "startsWithAnyOf() only works with strings");
      }, H);
      function H() {
      }
      function le(e) {
        return W(function(t) {
          return at(t), e(t.target.error), !1;
        });
      }
      function at(e) {
        e.stopPropagation && e.stopPropagation(), e.preventDefault && e.preventDefault();
      }
      var ut = "storagemutated", fn = "x-storagemutated-1", xe = rt(null, ut), Wr = (fe.prototype._lock = function() {
        return Xe(!C.global), ++this._reculock, this._reculock !== 1 || C.global || (C.lockOwnerFor = this), this;
      }, fe.prototype._unlock = function() {
        if (Xe(!C.global), --this._reculock == 0) for (C.global || (C.lockOwnerFor = null); 0 < this._blockedFuncs.length && !this._locked(); ) {
          var e = this._blockedFuncs.shift();
          try {
            Ie(e[1], e[0]);
          } catch {
          }
        }
        return this;
      }, fe.prototype._locked = function() {
        return this._reculock && C.lockOwnerFor !== this;
      }, fe.prototype.create = function(e) {
        var t = this;
        if (!this.mode) return this;
        var n = this.db.idbdb, r = this.db._state.dbOpenError;
        if (Xe(!this.idbtrans), !e && !n) switch (r && r.name) {
          case "DatabaseClosedError":
            throw new T.DatabaseClosed(r);
          case "MissingAPIError":
            throw new T.MissingAPI(r.message, r);
          default:
            throw new T.OpenFailed(r);
        }
        if (!this.active) throw new T.TransactionInactive();
        return Xe(this._completion._state === null), (e = this.idbtrans = e || (this.db.core || n).transaction(this.storeNames, this.mode, { durability: this.chromeTransactionDurability })).onerror = W(function(i) {
          at(i), t._reject(e.error);
        }), e.onabort = W(function(i) {
          at(i), t.active && t._reject(new T.Abort(e.error)), t.active = !1, t.on("abort").fire(i);
        }), e.oncomplete = W(function() {
          t.active = !1, t._resolve(), "mutatedParts" in e && xe.storagemutated.fire(e.mutatedParts);
        }), this;
      }, fe.prototype._promise = function(e, t, n) {
        var r = this;
        if (e === "readwrite" && this.mode !== "readwrite") return Y(new T.ReadOnly("Transaction is readonly"));
        if (!this.active) return Y(new T.TransactionInactive());
        if (this._locked()) return new E(function(o, a) {
          r._blockedFuncs.push([function() {
            r._promise(e, t, n).then(o, a);
          }, C]);
        });
        if (n) return ge(function() {
          var o = new E(function(a, u) {
            r._lock();
            var c = t(a, u, r);
            c && c.then && c.then(a, u);
          });
          return o.finally(function() {
            return r._unlock();
          }), o._lib = !0, o;
        });
        var i = new E(function(o, a) {
          var u = t(o, a, r);
          u && u.then && u.then(o, a);
        });
        return i._lib = !0, i;
      }, fe.prototype._root = function() {
        return this.parent ? this.parent._root() : this;
      }, fe.prototype.waitFor = function(e) {
        var t, n = this._root(), r = E.resolve(e);
        n._waitingFor ? n._waitingFor = n._waitingFor.then(function() {
          return r;
        }) : (n._waitingFor = r, n._waitingQueue = [], t = n.idbtrans.objectStore(n.storeNames[0]), function o() {
          for (++n._spinCount; n._waitingQueue.length; ) n._waitingQueue.shift()();
          n._waitingFor && (t.get(-1 / 0).onsuccess = o);
        }());
        var i = n._waitingFor;
        return new E(function(o, a) {
          r.then(function(u) {
            return n._waitingQueue.push(W(o.bind(null, u)));
          }, function(u) {
            return n._waitingQueue.push(W(a.bind(null, u)));
          }).finally(function() {
            n._waitingFor === i && (n._waitingFor = null);
          });
        });
      }, fe.prototype.abort = function() {
        this.active && (this.active = !1, this.idbtrans && this.idbtrans.abort(), this._reject(new T.Abort()));
      }, fe.prototype.table = function(e) {
        var t = this._memoizedTables || (this._memoizedTables = {});
        if (re(t, e)) return t[e];
        var n = this.schema[e];
        if (!n) throw new T.NotFound("Table " + e + " not part of transaction");
        return n = new this.db.Table(e, n, this), n.core = this.db.core.table(e), t[e] = n;
      }, fe);
      function fe() {
      }
      function hn(e, t, n, r, i, o, a) {
        return { name: e, keyPath: t, unique: n, multi: r, auto: i, compound: o, src: (n && !a ? "&" : "") + (r ? "*" : "") + (i ? "++" : "") + ar(t) };
      }
      function ar(e) {
        return typeof e == "string" ? e : e ? "[" + [].join.call(e, "+") + "]" : "";
      }
      function dn(e, t, n) {
        return { name: e, primKey: t, indexes: n, mappedClass: null, idxByName: (r = function(i) {
          return [i.name, i];
        }, n.reduce(function(i, o, a) {
          return a = r(o, a), a && (i[a[0]] = a[1]), i;
        }, {})) };
        var r;
      }
      var st = function(e) {
        try {
          return e.only([[]]), st = function() {
            return [[]];
          }, [[]];
        } catch {
          return st = function() {
            return Te;
          }, Te;
        }
      };
      function pn(e) {
        return e == null ? function() {
        } : typeof e == "string" ? (t = e).split(".").length === 1 ? function(n) {
          return n[t];
        } : function(n) {
          return he(n, t);
        } : function(n) {
          return he(n, e);
        };
        var t;
      }
      function ur(e) {
        return [].slice.call(e);
      }
      var Yr = 0;
      function ct(e) {
        return e == null ? ":id" : typeof e == "string" ? e : "[".concat(e.join("+"), "]");
      }
      function $r(e, t, c) {
        function r(h) {
          if (h.type === 3) return null;
          if (h.type === 4) throw new Error("Cannot convert never type to IDBKeyRange");
          var l = h.lower, d = h.upper, y = h.lowerOpen, h = h.upperOpen;
          return l === void 0 ? d === void 0 ? null : t.upperBound(d, !!h) : d === void 0 ? t.lowerBound(l, !!y) : t.bound(l, d, !!y, !!h);
        }
        function i(v) {
          var l, d = v.name;
          return { name: d, schema: v, mutate: function(y) {
            var h = y.trans, m = y.type, g = y.keys, b = y.values, w = y.range;
            return new Promise(function(_, O) {
              _ = W(_);
              var x = h.objectStore(d), k = x.keyPath == null, j = m === "put" || m === "add";
              if (!j && m !== "delete" && m !== "deleteRange") throw new Error("Invalid operation type: " + m);
              var P, K = (g || b || { length: 1 }).length;
              if (g && b && g.length !== b.length) throw new Error("Given keys array must have same length as given values array.");
              if (K === 0) return _({ numFailures: 0, failures: {}, results: [], lastResult: void 0 });
              function R(ne) {
                ++ae, at(ne);
              }
              var F = [], M = [], ae = 0;
              if (m === "deleteRange") {
                if (w.type === 4) return _({ numFailures: ae, failures: M, results: [], lastResult: void 0 });
                w.type === 3 ? F.push(P = x.clear()) : F.push(P = x.delete(r(w)));
              } else {
                var k = j ? k ? [b, g] : [b, null] : [g, null], B = k[0], ee = k[1];
                if (j) for (var te = 0; te < K; ++te) F.push(P = ee && ee[te] !== void 0 ? x[m](B[te], ee[te]) : x[m](B[te])), P.onerror = R;
                else for (te = 0; te < K; ++te) F.push(P = x[m](B[te])), P.onerror = R;
              }
              function Lt(ne) {
                ne = ne.target.result, F.forEach(function(Re, In) {
                  return Re.error != null && (M[In] = Re.error);
                }), _({ numFailures: ae, failures: M, results: m === "delete" ? g : F.map(function(Re) {
                  return Re.result;
                }), lastResult: ne });
              }
              P.onerror = function(ne) {
                R(ne), Lt(ne);
              }, P.onsuccess = Lt;
            });
          }, getMany: function(y) {
            var h = y.trans, m = y.keys;
            return new Promise(function(g, b) {
              g = W(g);
              for (var w, _ = h.objectStore(d), O = m.length, x = new Array(O), k = 0, j = 0, P = function(F) {
                F = F.target, x[F._pos] = F.result, ++j === k && g(x);
              }, K = le(b), R = 0; R < O; ++R) m[R] != null && ((w = _.get(m[R]))._pos = R, w.onsuccess = P, w.onerror = K, ++k);
              k === 0 && g(x);
            });
          }, get: function(y) {
            var h = y.trans, m = y.key;
            return new Promise(function(g, b) {
              g = W(g);
              var w = h.objectStore(d).get(m);
              w.onsuccess = function(_) {
                return g(_.target.result);
              }, w.onerror = le(b);
            });
          }, query: (l = f, function(y) {
            return new Promise(function(h, m) {
              h = W(h);
              var g, b, w, k = y.trans, _ = y.values, O = y.limit, P = y.query, x = O === 1 / 0 ? void 0 : O, j = P.index, P = P.range, k = k.objectStore(d), j = j.isPrimaryKey ? k : k.index(j.name), P = r(P);
              if (O === 0) return h({ result: [] });
              l ? ((x = _ ? j.getAll(P, x) : j.getAllKeys(P, x)).onsuccess = function(K) {
                return h({ result: K.target.result });
              }, x.onerror = le(m)) : (g = 0, b = !_ && "openKeyCursor" in j ? j.openKeyCursor(P) : j.openCursor(P), w = [], b.onsuccess = function(K) {
                var R = b.result;
                return R ? (w.push(_ ? R.value : R.primaryKey), ++g === O ? h({ result: w }) : void R.continue()) : h({ result: w });
              }, b.onerror = le(m));
            });
          }), openCursor: function(y) {
            var h = y.trans, m = y.values, g = y.query, b = y.reverse, w = y.unique;
            return new Promise(function(_, O) {
              _ = W(_);
              var j = g.index, x = g.range, k = h.objectStore(d), k = j.isPrimaryKey ? k : k.index(j.name), j = b ? w ? "prevunique" : "prev" : w ? "nextunique" : "next", P = !m && "openKeyCursor" in k ? k.openKeyCursor(r(x), j) : k.openCursor(r(x), j);
              P.onerror = le(O), P.onsuccess = W(function(K) {
                var R, F, M, ae, B = P.result;
                B ? (B.___id = ++Yr, B.done = !1, R = B.continue.bind(B), F = (F = B.continuePrimaryKey) && F.bind(B), M = B.advance.bind(B), ae = function() {
                  throw new Error("Cursor not stopped");
                }, B.trans = h, B.stop = B.continue = B.continuePrimaryKey = B.advance = function() {
                  throw new Error("Cursor not started");
                }, B.fail = W(O), B.next = function() {
                  var ee = this, te = 1;
                  return this.start(function() {
                    return te-- ? ee.continue() : ee.stop();
                  }).then(function() {
                    return ee;
                  });
                }, B.start = function(ee) {
                  function te() {
                    if (P.result) try {
                      ee();
                    } catch (ne) {
                      B.fail(ne);
                    }
                    else B.done = !0, B.start = function() {
                      throw new Error("Cursor behind last entry");
                    }, B.stop();
                  }
                  var Lt = new Promise(function(ne, Re) {
                    ne = W(ne), P.onerror = le(Re), B.fail = Re, B.stop = function(In) {
                      B.stop = B.continue = B.continuePrimaryKey = B.advance = ae, ne(In);
                    };
                  });
                  return P.onsuccess = W(function(ne) {
                    P.onsuccess = te, te();
                  }), B.continue = R, B.continuePrimaryKey = F, B.advance = M, te(), Lt;
                }, _(B)) : _(null);
              }, O);
            });
          }, count: function(y) {
            var h = y.query, m = y.trans, g = h.index, b = h.range;
            return new Promise(function(w, _) {
              var O = m.objectStore(d), x = g.isPrimaryKey ? O : O.index(g.name), O = r(b), x = O ? x.count(O) : x.count();
              x.onsuccess = W(function(k) {
                return w(k.target.result);
              }), x.onerror = le(_);
            });
          } };
        }
        var o, a, u, p = (a = c, u = ur((o = e).objectStoreNames), { schema: { name: o.name, tables: u.map(function(v) {
          return a.objectStore(v);
        }).map(function(v) {
          var l = v.keyPath, h = v.autoIncrement, d = A(l), y = {}, h = { name: v.name, primaryKey: { name: null, isPrimaryKey: !0, outbound: l == null, compound: d, keyPath: l, autoIncrement: h, unique: !0, extractKey: pn(l) }, indexes: ur(v.indexNames).map(function(m) {
            return v.index(m);
          }).map(function(w) {
            var g = w.name, b = w.unique, _ = w.multiEntry, w = w.keyPath, _ = { name: g, compound: A(w), keyPath: w, unique: b, multiEntry: _, extractKey: pn(w) };
            return y[ct(w)] = _;
          }), getIndexByKeyPath: function(m) {
            return y[ct(m)];
          } };
          return y[":id"] = h.primaryKey, l != null && (y[ct(l)] = h.primaryKey), h;
        }) }, hasGetAll: 0 < u.length && "getAll" in a.objectStore(u[0]) && !(typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604) }), c = p.schema, f = p.hasGetAll, p = c.tables.map(i), s = {};
        return p.forEach(function(v) {
          return s[v.name] = v;
        }), { stack: "dbcore", transaction: e.transaction.bind(e), table: function(v) {
          if (!s[v]) throw new Error("Table '".concat(v, "' not found"));
          return s[v];
        }, MIN_KEY: -1 / 0, MAX_KEY: st(t), schema: c };
      }
      function Qr(e, t, n, r) {
        var i = n.IDBKeyRange;
        return n.indexedDB, { dbcore: (r = $r(t, i, r), e.dbcore.reduce(function(o, a) {
          return a = a.create, D(D({}, o), a(o));
        }, r)) };
      }
      function St(e, r) {
        var n = r.db, r = Qr(e._middlewares, n, e._deps, r);
        e.core = r.dbcore, e.tables.forEach(function(i) {
          var o = i.name;
          e.core.schema.tables.some(function(a) {
            return a.name === o;
          }) && (i.core = e.core.table(o), e[o] instanceof e.Table && (e[o].core = i.core));
        });
      }
      function At(e, t, n, r) {
        n.forEach(function(i) {
          var o = r[i];
          t.forEach(function(a) {
            var u = function c(f, p) {
              return Or(f, p) || (f = J(f)) && c(f, p);
            }(a, i);
            (!u || "value" in u && u.value === void 0) && (a === e.Transaction.prototype || a instanceof e.Transaction ? ve(a, i, { get: function() {
              return this.table(i);
            }, set: function(c) {
              qn(this, i, { value: c, writable: !0, configurable: !0, enumerable: !0 });
            } }) : a[i] = new e.Table(i, o));
          });
        });
      }
      function yn(e, t) {
        t.forEach(function(n) {
          for (var r in n) n[r] instanceof e.Table && delete n[r];
        });
      }
      function Gr(e, t) {
        return e._cfg.version - t._cfg.version;
      }
      function Xr(e, t, n, r) {
        var i = e._dbSchema;
        n.objectStoreNames.contains("$meta") && !i.$meta && (i.$meta = dn("$meta", cr("")[0], []), e._storeNames.push("$meta"));
        var o = e._createTransaction("readwrite", e._storeNames, i);
        o.create(n), o._completion.catch(r);
        var a = o._reject.bind(o), u = C.transless || C;
        ge(function() {
          return C.trans = o, C.transless = u, t !== 0 ? (St(e, n), f = t, ((c = o).storeNames.includes("$meta") ? c.table("$meta").get("version").then(function(p) {
            return p ?? f;
          }) : E.resolve(f)).then(function(p) {
            return v = p, l = o, d = n, y = [], p = (s = e)._versions, h = s._dbSchema = It(0, s.idbdb, d), (p = p.filter(function(m) {
              return m._cfg.version >= v;
            })).length !== 0 ? (p.forEach(function(m) {
              y.push(function() {
                var g = h, b = m._cfg.dbschema;
                Tt(s, g, d), Tt(s, b, d), h = s._dbSchema = b;
                var w = vn(g, b);
                w.add.forEach(function(j) {
                  mn(d, j[0], j[1].primKey, j[1].indexes);
                }), w.change.forEach(function(j) {
                  if (j.recreate) throw new T.Upgrade("Not yet support for changing primary key");
                  var P = d.objectStore(j.name);
                  j.add.forEach(function(K) {
                    return Ct(P, K);
                  }), j.change.forEach(function(K) {
                    P.deleteIndex(K.name), Ct(P, K);
                  }), j.del.forEach(function(K) {
                    return P.deleteIndex(K);
                  });
                });
                var _ = m._cfg.contentUpgrade;
                if (_ && m._cfg.version > v) {
                  St(s, d), l._memoizedTables = {};
                  var O = Fn(b);
                  w.del.forEach(function(j) {
                    O[j] = g[j];
                  }), yn(s, [s.Transaction.prototype]), At(s, [s.Transaction.prototype], q(O), O), l.schema = O;
                  var x, k = Qt(_);
                  return k && We(), w = E.follow(function() {
                    var j;
                    (x = _(l)) && k && (j = be.bind(null, null), x.then(j, j));
                  }), x && typeof x.then == "function" ? E.resolve(x) : w.then(function() {
                    return x;
                  });
                }
              }), y.push(function(g) {
                var b, w, _ = m._cfg.dbschema;
                b = _, w = g, [].slice.call(w.db.objectStoreNames).forEach(function(O) {
                  return b[O] == null && w.db.deleteObjectStore(O);
                }), yn(s, [s.Transaction.prototype]), At(s, [s.Transaction.prototype], s._storeNames, s._dbSchema), l.schema = s._dbSchema;
              }), y.push(function(g) {
                s.idbdb.objectStoreNames.contains("$meta") && (Math.ceil(s.idbdb.version / 10) === m._cfg.version ? (s.idbdb.deleteObjectStore("$meta"), delete s._dbSchema.$meta, s._storeNames = s._storeNames.filter(function(b) {
                  return b !== "$meta";
                })) : g.objectStore("$meta").put(m._cfg.version, "version"));
              });
            }), function m() {
              return y.length ? E.resolve(y.shift()(l.idbtrans)).then(m) : E.resolve();
            }().then(function() {
              sr(h, d);
            })) : E.resolve();
            var s, v, l, d, y, h;
          }).catch(a)) : (q(i).forEach(function(p) {
            mn(n, p, i[p].primKey, i[p].indexes);
          }), St(e, n), void E.follow(function() {
            return e.on.populate.fire(o);
          }).catch(a));
          var c, f;
        });
      }
      function Hr(e, t) {
        sr(e._dbSchema, t), t.db.version % 10 != 0 || t.objectStoreNames.contains("$meta") || t.db.createObjectStore("$meta").add(Math.ceil(t.db.version / 10 - 1), "version");
        var n = It(0, e.idbdb, t);
        Tt(e, e._dbSchema, t);
        for (var r = 0, i = vn(n, e._dbSchema).change; r < i.length; r++) {
          var o = function(a) {
            if (a.change.length || a.recreate) return console.warn("Unable to patch indexes of table ".concat(a.name, " because it has changes on the type of index or primary key.")), { value: void 0 };
            var u = t.objectStore(a.name);
            a.add.forEach(function(c) {
              ce && console.debug("Dexie upgrade patch: Creating missing index ".concat(a.name, ".").concat(c.src)), Ct(u, c);
            });
          }(i[r]);
          if (typeof o == "object") return o.value;
        }
      }
      function vn(e, t) {
        var n, r = { del: [], add: [], change: [] };
        for (n in e) t[n] || r.del.push(n);
        for (n in t) {
          var i = e[n], o = t[n];
          if (i) {
            var a = { name: n, def: o, recreate: !1, del: [], add: [], change: [] };
            if ("" + (i.primKey.keyPath || "") != "" + (o.primKey.keyPath || "") || i.primKey.auto !== o.primKey.auto) a.recreate = !0, r.change.push(a);
            else {
              var u = i.idxByName, c = o.idxByName, f = void 0;
              for (f in u) c[f] || a.del.push(f);
              for (f in c) {
                var p = u[f], s = c[f];
                p ? p.src !== s.src && a.change.push(s) : a.add.push(s);
              }
              (0 < a.del.length || 0 < a.add.length || 0 < a.change.length) && r.change.push(a);
            }
          } else r.add.push([n, o]);
        }
        return r;
      }
      function mn(e, t, n, r) {
        var i = e.db.createObjectStore(t, n.keyPath ? { keyPath: n.keyPath, autoIncrement: n.auto } : { autoIncrement: n.auto });
        return r.forEach(function(o) {
          return Ct(i, o);
        }), i;
      }
      function sr(e, t) {
        q(e).forEach(function(n) {
          t.db.objectStoreNames.contains(n) || (ce && console.debug("Dexie: Creating missing table", n), mn(t, n, e[n].primKey, e[n].indexes));
        });
      }
      function Ct(e, t) {
        e.createIndex(t.name, t.keyPath, { unique: t.unique, multiEntry: t.multi });
      }
      function It(e, t, n) {
        var r = {};
        return dt(t.objectStoreNames, 0).forEach(function(i) {
          for (var o = n.objectStore(i), a = hn(ar(f = o.keyPath), f || "", !0, !1, !!o.autoIncrement, f && typeof f != "string", !0), u = [], c = 0; c < o.indexNames.length; ++c) {
            var p = o.index(o.indexNames[c]), f = p.keyPath, p = hn(p.name, f, !!p.unique, !!p.multiEntry, !1, f && typeof f != "string", !1);
            u.push(p);
          }
          r[i] = dn(i, a, u);
        }), r;
      }
      function Tt(e, t, n) {
        for (var r = n.db.objectStoreNames, i = 0; i < r.length; ++i) {
          var o = r[i], a = n.objectStore(o);
          e._hasGetAll = "getAll" in a;
          for (var u = 0; u < a.indexNames.length; ++u) {
            var c = a.indexNames[u], f = a.index(c).keyPath, p = typeof f == "string" ? f : "[" + dt(f).join("+") + "]";
            !t[o] || (f = t[o].idxByName[p]) && (f.name = c, delete t[o].idxByName[p], t[o].idxByName[c] = f);
          }
        }
        typeof navigator < "u" && /Safari/.test(navigator.userAgent) && !/(Chrome\/|Edge\/)/.test(navigator.userAgent) && Q.WorkerGlobalScope && Q instanceof Q.WorkerGlobalScope && [].concat(navigator.userAgent.match(/Safari\/(\d*)/))[1] < 604 && (e._hasGetAll = !1);
      }
      function cr(e) {
        return e.split(",").map(function(t, n) {
          var r = (t = t.trim()).replace(/([&*]|\+\+)/g, ""), i = /^\[/.test(r) ? r.match(/^\[(.*)\]$/)[1].split("+") : r;
          return hn(r, i || null, /\&/.test(t), /\*/.test(t), /\+\+/.test(t), A(i), n === 0);
        });
      }
      var Jr = (Dt.prototype._parseStoresSpec = function(e, t) {
        q(e).forEach(function(n) {
          if (e[n] !== null) {
            var r = cr(e[n]), i = r.shift();
            if (i.unique = !0, i.multi) throw new T.Schema("Primary key cannot be multi-valued");
            r.forEach(function(o) {
              if (o.auto) throw new T.Schema("Only primary key can be marked as autoIncrement (++)");
              if (!o.keyPath) throw new T.Schema("Index must have a name and cannot be an empty string");
            }), t[n] = dn(n, i, r);
          }
        });
      }, Dt.prototype.stores = function(n) {
        var t = this.db;
        this._cfg.storesSource = this._cfg.storesSource ? V(this._cfg.storesSource, n) : n;
        var n = t._versions, r = {}, i = {};
        return n.forEach(function(o) {
          V(r, o._cfg.storesSource), i = o._cfg.dbschema = {}, o._parseStoresSpec(r, i);
        }), t._dbSchema = i, yn(t, [t._allTables, t, t.Transaction.prototype]), At(t, [t._allTables, t, t.Transaction.prototype, this._cfg.tables], q(i), i), t._storeNames = q(i), this;
      }, Dt.prototype.upgrade = function(e) {
        return this._cfg.contentUpgrade = Xt(this._cfg.contentUpgrade || U, e), this;
      }, Dt);
      function Dt() {
      }
      function gn(e, t) {
        var n = e._dbNamesDB;
        return n || (n = e._dbNamesDB = new ye(Pt, { addons: [], indexedDB: e, IDBKeyRange: t })).version(1).stores({ dbnames: "name" }), n.table("dbnames");
      }
      function bn(e) {
        return e && typeof e.databases == "function";
      }
      function wn(e) {
        return ge(function() {
          return C.letThrough = !0, e();
        });
      }
      function _n(e) {
        return !("from" in e);
      }
      var Z = function(e, t) {
        if (!this) {
          var n = new Z();
          return e && "d" in e && V(n, e), n;
        }
        V(this, arguments.length ? { d: 1, from: e, to: 1 < arguments.length ? t : e } : { d: 0 });
      };
      function lt(e, t, n) {
        var r = N(t, n);
        if (!isNaN(r)) {
          if (0 < r) throw RangeError();
          if (_n(e)) return V(e, { from: t, to: n, d: 1 });
          var i = e.l, r = e.r;
          if (N(n, e.from) < 0) return i ? lt(i, t, n) : e.l = { from: t, to: n, d: 1, l: null, r: null }, fr(e);
          if (0 < N(t, e.to)) return r ? lt(r, t, n) : e.r = { from: t, to: n, d: 1, l: null, r: null }, fr(e);
          N(t, e.from) < 0 && (e.from = t, e.l = null, e.d = r ? r.d + 1 : 1), 0 < N(n, e.to) && (e.to = n, e.r = null, e.d = e.l ? e.l.d + 1 : 1), n = !e.r, i && !e.l && ft(e, i), r && n && ft(e, r);
        }
      }
      function ft(e, t) {
        _n(t) || function n(r, c) {
          var o = c.from, a = c.to, u = c.l, c = c.r;
          lt(r, o, a), u && n(r, u), c && n(r, c);
        }(e, t);
      }
      function lr(e, t) {
        var n = qt(t), r = n.next();
        if (r.done) return !1;
        for (var i = r.value, o = qt(e), a = o.next(i.from), u = a.value; !r.done && !a.done; ) {
          if (N(u.from, i.to) <= 0 && 0 <= N(u.to, i.from)) return !0;
          N(i.from, u.from) < 0 ? i = (r = n.next(u.from)).value : u = (a = o.next(i.from)).value;
        }
        return !1;
      }
      function qt(e) {
        var t = _n(e) ? null : { s: 0, n: e };
        return { next: function(n) {
          for (var r = 0 < arguments.length; t; ) switch (t.s) {
            case 0:
              if (t.s = 1, r) for (; t.n.l && N(n, t.n.from) < 0; ) t = { up: t, n: t.n.l, s: 1 };
              else for (; t.n.l; ) t = { up: t, n: t.n.l, s: 1 };
            case 1:
              if (t.s = 2, !r || N(n, t.n.to) <= 0) return { value: t.n, done: !1 };
            case 2:
              if (t.n.r) {
                t.s = 3, t = { up: t, n: t.n.r, s: 0 };
                continue;
              }
            case 3:
              t = t.up;
          }
          return { done: !0 };
        } };
      }
      function fr(e) {
        var t, n, r = (((t = e.r) === null || t === void 0 ? void 0 : t.d) || 0) - (((n = e.l) === null || n === void 0 ? void 0 : n.d) || 0), i = 1 < r ? "r" : r < -1 ? "l" : "";
        i && (t = i == "r" ? "l" : "r", n = D({}, e), r = e[i], e.from = r.from, e.to = r.to, e[i] = r[i], n[i] = r[t], (e[t] = n).d = hr(n)), e.d = hr(e);
      }
      function hr(n) {
        var t = n.r, n = n.l;
        return (t ? n ? Math.max(t.d, n.d) : t.d : n ? n.d : 0) + 1;
      }
      function Bt(e, t) {
        return q(t).forEach(function(n) {
          e[n] ? ft(e[n], t[n]) : e[n] = function r(i) {
            var o, a, u = {};
            for (o in i) re(i, o) && (a = i[o], u[o] = !a || typeof a != "object" || Nn.has(a.constructor) ? a : r(a));
            return u;
          }(t[n]);
        }), e;
      }
      function xn(e, t) {
        return e.all || t.all || Object.keys(e).some(function(n) {
          return t[n] && lr(t[n], e[n]);
        });
      }
      Fe(Z.prototype, ((se = { add: function(e) {
        return ft(this, e), this;
      }, addKey: function(e) {
        return lt(this, e, e), this;
      }, addKeys: function(e) {
        var t = this;
        return e.forEach(function(n) {
          return lt(t, n, n);
        }), this;
      }, hasKey: function(e) {
        var t = qt(this).next(e).value;
        return t && N(t.from, e) <= 0 && 0 <= N(t.to, e);
      } })[$t] = function() {
        return qt(this);
      }, se));
      var qe = {}, kn = {}, Pn = !1;
      function Rt(e) {
        Bt(kn, e), Pn || (Pn = !0, setTimeout(function() {
          Pn = !1, On(kn, !(kn = {}));
        }, 0));
      }
      function On(e, t) {
        t === void 0 && (t = !1);
        var n = /* @__PURE__ */ new Set();
        if (e.all) for (var r = 0, i = Object.values(qe); r < i.length; r++) dr(a = i[r], e, n, t);
        else for (var o in e) {
          var a, u = /^idb\:\/\/(.*)\/(.*)\//.exec(o);
          u && (o = u[1], u = u[2], (a = qe["idb://".concat(o, "/").concat(u)]) && dr(a, e, n, t));
        }
        n.forEach(function(c) {
          return c();
        });
      }
      function dr(e, t, n, r) {
        for (var i = [], o = 0, a = Object.entries(e.queries.query); o < a.length; o++) {
          for (var u = a[o], c = u[0], f = [], p = 0, s = u[1]; p < s.length; p++) {
            var v = s[p];
            xn(t, v.obsSet) ? v.subscribers.forEach(function(h) {
              return n.add(h);
            }) : r && f.push(v);
          }
          r && i.push([c, f]);
        }
        if (r) for (var l = 0, d = i; l < d.length; l++) {
          var y = d[l], c = y[0], f = y[1];
          e.queries.query[c] = f;
        }
      }
      function Zr(e) {
        var t = e._state, n = e._deps.indexedDB;
        if (t.isBeingOpened || e.idbdb) return t.dbReadyPromise.then(function() {
          return t.dbOpenError ? Y(t.dbOpenError) : e;
        });
        t.isBeingOpened = !0, t.dbOpenError = null, t.openComplete = !1;
        var r = t.openCanceller, i = Math.round(10 * e.verno), o = !1;
        function a() {
          if (t.openCanceller !== r) throw new T.DatabaseClosed("db.open() was cancelled");
        }
        function u() {
          return new E(function(v, l) {
            if (a(), !n) throw new T.MissingAPI();
            var d = e.name, y = t.autoSchema || !i ? n.open(d) : n.open(d, i);
            if (!y) throw new T.MissingAPI();
            y.onerror = le(l), y.onblocked = W(e._fireOnBlocked), y.onupgradeneeded = W(function(h) {
              var m;
              p = y.transaction, t.autoSchema && !e._options.allowEmptyDB ? (y.onerror = at, p.abort(), y.result.close(), (m = n.deleteDatabase(d)).onsuccess = m.onerror = W(function() {
                l(new T.NoSuchDatabase("Database ".concat(d, " doesnt exist")));
              })) : (p.onerror = le(l), h = h.oldVersion > Math.pow(2, 62) ? 0 : h.oldVersion, s = h < 1, e.idbdb = y.result, o && Hr(e, p), Xr(e, h / 10, p, l));
            }, l), y.onsuccess = W(function() {
              p = null;
              var h, m, g, b, w, _ = e.idbdb = y.result, O = dt(_.objectStoreNames);
              if (0 < O.length) try {
                var x = _.transaction((b = O).length === 1 ? b[0] : b, "readonly");
                if (t.autoSchema) m = _, g = x, (h = e).verno = m.version / 10, g = h._dbSchema = It(0, m, g), h._storeNames = dt(m.objectStoreNames, 0), At(h, [h._allTables], q(g), g);
                else if (Tt(e, e._dbSchema, x), ((w = vn(It(0, (w = e).idbdb, x), w._dbSchema)).add.length || w.change.some(function(k) {
                  return k.add.length || k.change.length;
                })) && !o) return console.warn("Dexie SchemaDiff: Schema was extended without increasing the number passed to db.version(). Dexie will add missing parts and increment native version number to workaround this."), _.close(), i = _.version + 1, o = !0, v(u());
                St(e, x);
              } catch {
              }
              Ye.push(e), _.onversionchange = W(function(k) {
                t.vcFired = !0, e.on("versionchange").fire(k);
              }), _.onclose = W(function(k) {
                e.on("close").fire(k);
              }), s && (w = e._deps, x = d, _ = w.indexedDB, w = w.IDBKeyRange, bn(_) || x === Pt || gn(_, w).put({ name: x }).catch(U)), v();
            }, l);
          }).catch(function(v) {
            switch (v == null ? void 0 : v.name) {
              case "UnknownError":
                if (0 < t.PR1398_maxLoop) return t.PR1398_maxLoop--, console.warn("Dexie: Workaround for Chrome UnknownError on open()"), u();
                break;
              case "VersionError":
                if (0 < i) return i = 0, u();
            }
            return E.reject(v);
          });
        }
        var c, f = t.dbReadyResolve, p = null, s = !1;
        return E.race([r, (typeof navigator > "u" ? E.resolve() : !navigator.userAgentData && /Safari\//.test(navigator.userAgent) && !/Chrom(e|ium)\//.test(navigator.userAgent) && indexedDB.databases ? new Promise(function(v) {
          function l() {
            return indexedDB.databases().finally(v);
          }
          c = setInterval(l, 100), l();
        }).finally(function() {
          return clearInterval(c);
        }) : Promise.resolve()).then(u)]).then(function() {
          return a(), t.onReadyBeingFired = [], E.resolve(wn(function() {
            return e.on.ready.fire(e.vip);
          })).then(function v() {
            if (0 < t.onReadyBeingFired.length) {
              var l = t.onReadyBeingFired.reduce(Xt, U);
              return t.onReadyBeingFired = [], E.resolve(wn(function() {
                return l(e.vip);
              })).then(v);
            }
          });
        }).finally(function() {
          t.openCanceller === r && (t.onReadyBeingFired = null, t.isBeingOpened = !1);
        }).catch(function(v) {
          t.dbOpenError = v;
          try {
            p && p.abort();
          } catch {
          }
          return r === t.openCanceller && e._close(), Y(v);
        }).finally(function() {
          t.openComplete = !0, f();
        }).then(function() {
          var v;
          return s && (v = {}, e.tables.forEach(function(l) {
            l.schema.indexes.forEach(function(d) {
              d.name && (v["idb://".concat(e.name, "/").concat(l.name, "/").concat(d.name)] = new Z(-1 / 0, [[[]]]));
            }), v["idb://".concat(e.name, "/").concat(l.name, "/")] = v["idb://".concat(e.name, "/").concat(l.name, "/:dels")] = new Z(-1 / 0, [[[]]]);
          }), xe(ut).fire(v), On(v, !0)), e;
        });
      }
      function jn(e) {
        function t(o) {
          return e.next(o);
        }
        var n = i(t), r = i(function(o) {
          return e.throw(o);
        });
        function i(o) {
          return function(c) {
            var u = o(c), c = u.value;
            return u.done ? c : c && typeof c.then == "function" ? c.then(n, r) : A(c) ? Promise.all(c).then(n, r) : n(c);
          };
        }
        return i(t)();
      }
      function Ft(e, t, n) {
        for (var r = A(e) ? e.slice() : [e], i = 0; i < n; ++i) r.push(t);
        return r;
      }
      var ei = { stack: "dbcore", name: "VirtualIndexMiddleware", level: 1, create: function(e) {
        return D(D({}, e), { table: function(t) {
          var n = e.table(t), r = n.schema, i = {}, o = [];
          function a(s, v, l) {
            var d = ct(s), y = i[d] = i[d] || [], h = s == null ? 0 : typeof s == "string" ? 1 : s.length, m = 0 < v, m = D(D({}, l), { name: m ? "".concat(d, "(virtual-from:").concat(l.name, ")") : l.name, lowLevelIndex: l, isVirtual: m, keyTail: v, keyLength: h, extractKey: pn(s), unique: !m && l.unique });
            return y.push(m), m.isPrimaryKey || o.push(m), 1 < h && a(h === 2 ? s[0] : s.slice(0, h - 1), v + 1, l), y.sort(function(g, b) {
              return g.keyTail - b.keyTail;
            }), m;
          }
          t = a(r.primaryKey.keyPath, 0, r.primaryKey), i[":id"] = [t];
          for (var u = 0, c = r.indexes; u < c.length; u++) {
            var f = c[u];
            a(f.keyPath, 0, f);
          }
          function p(s) {
            var v, l = s.query.index;
            return l.isVirtual ? D(D({}, s), { query: { index: l.lowLevelIndex, range: (v = s.query.range, l = l.keyTail, { type: v.type === 1 ? 2 : v.type, lower: Ft(v.lower, v.lowerOpen ? e.MAX_KEY : e.MIN_KEY, l), lowerOpen: !0, upper: Ft(v.upper, v.upperOpen ? e.MIN_KEY : e.MAX_KEY, l), upperOpen: !0 }) } }) : s;
          }
          return D(D({}, n), { schema: D(D({}, r), { primaryKey: t, indexes: o, getIndexByKeyPath: function(s) {
            return (s = i[ct(s)]) && s[0];
          } }), count: function(s) {
            return n.count(p(s));
          }, query: function(s) {
            return n.query(p(s));
          }, openCursor: function(s) {
            var v = s.query.index, l = v.keyTail, d = v.isVirtual, y = v.keyLength;
            return d ? n.openCursor(p(s)).then(function(m) {
              return m && h(m);
            }) : n.openCursor(s);
            function h(m) {
              return Object.create(m, { continue: { value: function(g) {
                g != null ? m.continue(Ft(g, s.reverse ? e.MAX_KEY : e.MIN_KEY, l)) : s.unique ? m.continue(m.key.slice(0, y).concat(s.reverse ? e.MIN_KEY : e.MAX_KEY, l)) : m.continue();
              } }, continuePrimaryKey: { value: function(g, b) {
                m.continuePrimaryKey(Ft(g, e.MAX_KEY, l), b);
              } }, primaryKey: { get: function() {
                return m.primaryKey;
              } }, key: { get: function() {
                var g = m.key;
                return y === 1 ? g[0] : g.slice(0, y);
              } }, value: { get: function() {
                return m.value;
              } } });
            }
          } });
        } });
      } };
      function En(e, t, n, r) {
        return n = n || {}, r = r || "", q(e).forEach(function(i) {
          var o, a, u;
          re(t, i) ? (o = e[i], a = t[i], typeof o == "object" && typeof a == "object" && o && a ? (u = Yt(o)) !== Yt(a) ? n[r + i] = t[i] : u === "Object" ? En(o, a, n, r + i + ".") : o !== a && (n[r + i] = t[i]) : o !== a && (n[r + i] = t[i])) : n[r + i] = void 0;
        }), q(t).forEach(function(i) {
          re(e, i) || (n[r + i] = t[i]);
        }), n;
      }
      function Kn(e, t) {
        return t.type === "delete" ? t.keys : t.keys || t.values.map(e.extractKey);
      }
      var ti = { stack: "dbcore", name: "HooksMiddleware", level: 2, create: function(e) {
        return D(D({}, e), { table: function(t) {
          var n = e.table(t), r = n.schema.primaryKey;
          return D(D({}, n), { mutate: function(i) {
            var o = C.trans, a = o.table(t).hook, u = a.deleting, c = a.creating, f = a.updating;
            switch (i.type) {
              case "add":
                if (c.fire === U) break;
                return o._promise("readwrite", function() {
                  return p(i);
                }, !0);
              case "put":
                if (c.fire === U && f.fire === U) break;
                return o._promise("readwrite", function() {
                  return p(i);
                }, !0);
              case "delete":
                if (u.fire === U) break;
                return o._promise("readwrite", function() {
                  return p(i);
                }, !0);
              case "deleteRange":
                if (u.fire === U) break;
                return o._promise("readwrite", function() {
                  return function s(v, l, d) {
                    return n.query({ trans: v, values: !1, query: { index: r, range: l }, limit: d }).then(function(y) {
                      var h = y.result;
                      return p({ type: "delete", keys: h, trans: v }).then(function(m) {
                        return 0 < m.numFailures ? Promise.reject(m.failures[0]) : h.length < d ? { failures: [], numFailures: 0, lastResult: void 0 } : s(v, D(D({}, l), { lower: h[h.length - 1], lowerOpen: !0 }), d);
                      });
                    });
                  }(i.trans, i.range, 1e4);
                }, !0);
            }
            return n.mutate(i);
            function p(s) {
              var v, l, d, y = C.trans, h = s.keys || Kn(r, s);
              if (!h) throw new Error("Keys missing");
              return (s = s.type === "add" || s.type === "put" ? D(D({}, s), { keys: h }) : D({}, s)).type !== "delete" && (s.values = Pe([], s.values)), s.keys && (s.keys = Pe([], s.keys)), v = n, d = h, ((l = s).type === "add" ? Promise.resolve([]) : v.getMany({ trans: l.trans, keys: d, cache: "immutable" })).then(function(m) {
                var g = h.map(function(b, w) {
                  var _, O, x, k = m[w], j = { onerror: null, onsuccess: null };
                  return s.type === "delete" ? u.fire.call(j, b, k, y) : s.type === "add" || k === void 0 ? (_ = c.fire.call(j, b, s.values[w], y), b == null && _ != null && (s.keys[w] = b = _, r.outbound || ie(s.values[w], r.keyPath, b))) : (_ = En(k, s.values[w]), (O = f.fire.call(j, _, b, k, y)) && (x = s.values[w], Object.keys(O).forEach(function(P) {
                    re(x, P) ? x[P] = O[P] : ie(x, P, O[P]);
                  }))), j;
                });
                return n.mutate(s).then(function(b) {
                  for (var w = b.failures, _ = b.results, O = b.numFailures, b = b.lastResult, x = 0; x < h.length; ++x) {
                    var k = (_ || h)[x], j = g[x];
                    k == null ? j.onerror && j.onerror(w[x]) : j.onsuccess && j.onsuccess(s.type === "put" && m[x] ? s.values[x] : k);
                  }
                  return { failures: w, results: _, numFailures: O, lastResult: b };
                }).catch(function(b) {
                  return g.forEach(function(w) {
                    return w.onerror && w.onerror(b);
                  }), Promise.reject(b);
                });
              });
            }
          } });
        } });
      } };
      function pr(e, t, n) {
        try {
          if (!t || t.keys.length < e.length) return null;
          for (var r = [], i = 0, o = 0; i < t.keys.length && o < e.length; ++i) N(t.keys[i], e[o]) === 0 && (r.push(n ? Oe(t.values[i]) : t.values[i]), ++o);
          return r.length === e.length ? r : null;
        } catch {
          return null;
        }
      }
      var ni = { stack: "dbcore", level: -1, create: function(e) {
        return { table: function(t) {
          var n = e.table(t);
          return D(D({}, n), { getMany: function(r) {
            if (!r.cache) return n.getMany(r);
            var i = pr(r.keys, r.trans._cache, r.cache === "clone");
            return i ? E.resolve(i) : n.getMany(r).then(function(o) {
              return r.trans._cache = { keys: r.keys, values: r.cache === "clone" ? Oe(o) : o }, o;
            });
          }, mutate: function(r) {
            return r.type !== "add" && (r.trans._cache = null), n.mutate(r);
          } });
        } };
      } };
      function yr(e, t) {
        return e.trans.mode === "readonly" && !!e.subscr && !e.trans.explicit && e.trans.db._options.cache !== "disabled" && !t.schema.primaryKey.outbound;
      }
      function vr(e, t) {
        switch (e) {
          case "query":
            return t.values && !t.unique;
          case "get":
          case "getMany":
          case "count":
          case "openCursor":
            return !1;
        }
      }
      var ri = { stack: "dbcore", level: 0, name: "Observability", create: function(e) {
        var t = e.schema.name, n = new Z(e.MIN_KEY, e.MAX_KEY);
        return D(D({}, e), { transaction: function(r, i, o) {
          if (C.subscr && i !== "readonly") throw new T.ReadOnly("Readwrite transaction in liveQuery context. Querier source: ".concat(C.querier));
          return e.transaction(r, i, o);
        }, table: function(r) {
          var i = e.table(r), o = i.schema, a = o.primaryKey, s = o.indexes, u = a.extractKey, c = a.outbound, f = a.autoIncrement && s.filter(function(l) {
            return l.compound && l.keyPath.includes(a.keyPath);
          }), p = D(D({}, i), { mutate: function(l) {
            function d(P) {
              return P = "idb://".concat(t, "/").concat(r, "/").concat(P), b[P] || (b[P] = new Z());
            }
            var y, h, m, g = l.trans, b = l.mutatedParts || (l.mutatedParts = {}), w = d(""), _ = d(":dels"), O = l.type, j = l.type === "deleteRange" ? [l.range] : l.type === "delete" ? [l.keys] : l.values.length < 50 ? [Kn(a, l).filter(function(P) {
              return P;
            }), l.values] : [], x = j[0], k = j[1], j = l.trans._cache;
            return A(x) ? (w.addKeys(x), (j = O === "delete" || x.length === k.length ? pr(x, j) : null) || _.addKeys(x), (j || k) && (y = d, h = j, m = k, o.indexes.forEach(function(P) {
              var K = y(P.name || "");
              function R(M) {
                return M != null ? P.extractKey(M) : null;
              }
              function F(M) {
                return P.multiEntry && A(M) ? M.forEach(function(ae) {
                  return K.addKey(ae);
                }) : K.addKey(M);
              }
              (h || m).forEach(function(M, ee) {
                var B = h && R(h[ee]), ee = m && R(m[ee]);
                N(B, ee) !== 0 && (B != null && F(B), ee != null && F(ee));
              });
            }))) : x ? (k = { from: (k = x.lower) !== null && k !== void 0 ? k : e.MIN_KEY, to: (k = x.upper) !== null && k !== void 0 ? k : e.MAX_KEY }, _.add(k), w.add(k)) : (w.add(n), _.add(n), o.indexes.forEach(function(P) {
              return d(P.name).add(n);
            })), i.mutate(l).then(function(P) {
              return !x || l.type !== "add" && l.type !== "put" || (w.addKeys(P.results), f && f.forEach(function(K) {
                for (var R = l.values.map(function(B) {
                  return K.extractKey(B);
                }), F = K.keyPath.findIndex(function(B) {
                  return B === a.keyPath;
                }), M = 0, ae = P.results.length; M < ae; ++M) R[M][F] = P.results[M];
                d(K.name).addKeys(R);
              })), g.mutatedParts = Bt(g.mutatedParts || {}, b), P;
            });
          } }), s = function(d) {
            var y = d.query, d = y.index, y = y.range;
            return [d, new Z((d = y.lower) !== null && d !== void 0 ? d : e.MIN_KEY, (y = y.upper) !== null && y !== void 0 ? y : e.MAX_KEY)];
          }, v = { get: function(l) {
            return [a, new Z(l.key)];
          }, getMany: function(l) {
            return [a, new Z().addKeys(l.keys)];
          }, count: s, query: s, openCursor: s };
          return q(v).forEach(function(l) {
            p[l] = function(d) {
              var y = C.subscr, h = !!y, m = yr(C, i) && vr(l, d) ? d.obsSet = {} : y;
              if (h) {
                var g = function(k) {
                  return k = "idb://".concat(t, "/").concat(r, "/").concat(k), m[k] || (m[k] = new Z());
                }, b = g(""), w = g(":dels"), y = v[l](d), h = y[0], y = y[1];
                if ((l === "query" && h.isPrimaryKey && !d.values ? w : g(h.name || "")).add(y), !h.isPrimaryKey) {
                  if (l !== "count") {
                    var _ = l === "query" && c && d.values && i.query(D(D({}, d), { values: !1 }));
                    return i[l].apply(this, arguments).then(function(k) {
                      if (l === "query") {
                        if (c && d.values) return _.then(function(R) {
                          return R = R.result, b.addKeys(R), k;
                        });
                        var j = d.values ? k.result.map(u) : k.result;
                        (d.values ? b : w).addKeys(j);
                      } else if (l === "openCursor") {
                        var P = k, K = d.values;
                        return P && Object.create(P, { key: { get: function() {
                          return w.addKey(P.primaryKey), P.key;
                        } }, primaryKey: { get: function() {
                          var R = P.primaryKey;
                          return w.addKey(R), R;
                        } }, value: { get: function() {
                          return K && b.addKey(P.primaryKey), P.value;
                        } } });
                      }
                      return k;
                    });
                  }
                  w.add(n);
                }
              }
              return i[l].apply(this, arguments);
            };
          }), p;
        } });
      } };
      function mr(e, t, n) {
        if (n.numFailures === 0) return t;
        if (t.type === "deleteRange") return null;
        var r = t.keys ? t.keys.length : "values" in t && t.values ? t.values.length : 1;
        return n.numFailures === r ? null : (t = D({}, t), A(t.keys) && (t.keys = t.keys.filter(function(i, o) {
          return !(o in n.failures);
        })), "values" in t && A(t.values) && (t.values = t.values.filter(function(i, o) {
          return !(o in n.failures);
        })), t);
      }
      function Sn(e, t) {
        return n = e, ((r = t).lower === void 0 || (r.lowerOpen ? 0 < N(n, r.lower) : 0 <= N(n, r.lower))) && (e = e, (t = t).upper === void 0 || (t.upperOpen ? N(e, t.upper) < 0 : N(e, t.upper) <= 0));
        var n, r;
      }
      function gr(e, t, v, r, i, o) {
        if (!v || v.length === 0) return e;
        var a = t.query.index, u = a.multiEntry, c = t.query.range, f = r.schema.primaryKey.extractKey, p = a.extractKey, s = (a.lowLevelIndex || a).extractKey, v = v.reduce(function(l, d) {
          var y = l, h = [];
          if (d.type === "add" || d.type === "put") for (var m = new Z(), g = d.values.length - 1; 0 <= g; --g) {
            var b, w = d.values[g], _ = f(w);
            m.hasKey(_) || (b = p(w), (u && A(b) ? b.some(function(P) {
              return Sn(P, c);
            }) : Sn(b, c)) && (m.addKey(_), h.push(w)));
          }
          switch (d.type) {
            case "add":
              var O = new Z().addKeys(t.values ? l.map(function(K) {
                return f(K);
              }) : l), y = l.concat(t.values ? h.filter(function(K) {
                return K = f(K), !O.hasKey(K) && (O.addKey(K), !0);
              }) : h.map(function(K) {
                return f(K);
              }).filter(function(K) {
                return !O.hasKey(K) && (O.addKey(K), !0);
              }));
              break;
            case "put":
              var x = new Z().addKeys(d.values.map(function(K) {
                return f(K);
              }));
              y = l.filter(function(K) {
                return !x.hasKey(t.values ? f(K) : K);
              }).concat(t.values ? h : h.map(function(K) {
                return f(K);
              }));
              break;
            case "delete":
              var k = new Z().addKeys(d.keys);
              y = l.filter(function(K) {
                return !k.hasKey(t.values ? f(K) : K);
              });
              break;
            case "deleteRange":
              var j = d.range;
              y = l.filter(function(K) {
                return !Sn(f(K), j);
              });
          }
          return y;
        }, e);
        return v === e ? e : (v.sort(function(l, d) {
          return N(s(l), s(d)) || N(f(l), f(d));
        }), t.limit && t.limit < 1 / 0 && (v.length > t.limit ? v.length = t.limit : e.length === t.limit && v.length < t.limit && (i.dirty = !0)), o ? Object.freeze(v) : v);
      }
      function br(e, t) {
        return N(e.lower, t.lower) === 0 && N(e.upper, t.upper) === 0 && !!e.lowerOpen == !!t.lowerOpen && !!e.upperOpen == !!t.upperOpen;
      }
      function ii(e, t) {
        return function(n, r, i, o) {
          if (n === void 0) return r !== void 0 ? -1 : 0;
          if (r === void 0) return 1;
          if ((r = N(n, r)) === 0) {
            if (i && o) return 0;
            if (i) return 1;
            if (o) return -1;
          }
          return r;
        }(e.lower, t.lower, e.lowerOpen, t.lowerOpen) <= 0 && 0 <= function(n, r, i, o) {
          if (n === void 0) return r !== void 0 ? 1 : 0;
          if (r === void 0) return -1;
          if ((r = N(n, r)) === 0) {
            if (i && o) return 0;
            if (i) return -1;
            if (o) return 1;
          }
          return r;
        }(e.upper, t.upper, e.upperOpen, t.upperOpen);
      }
      function oi(e, t, n, r) {
        e.subscribers.add(n), r.addEventListener("abort", function() {
          var i, o;
          e.subscribers.delete(n), e.subscribers.size === 0 && (i = e, o = t, setTimeout(function() {
            i.subscribers.size === 0 && je(o, i);
          }, 3e3));
        });
      }
      var ai = { stack: "dbcore", level: 0, name: "Cache", create: function(e) {
        var t = e.schema.name;
        return D(D({}, e), { transaction: function(n, r, i) {
          var o, a, u = e.transaction(n, r, i);
          return r === "readwrite" && (a = (o = new AbortController()).signal, i = function(c) {
            return function() {
              if (o.abort(), r === "readwrite") {
                for (var f = /* @__PURE__ */ new Set(), p = 0, s = n; p < s.length; p++) {
                  var v = s[p], l = qe["idb://".concat(t, "/").concat(v)];
                  if (l) {
                    var d = e.table(v), y = l.optimisticOps.filter(function(K) {
                      return K.trans === u;
                    });
                    if (u._explicit && c && u.mutatedParts) for (var h = 0, m = Object.values(l.queries.query); h < m.length; h++) for (var g = 0, b = (O = m[h]).slice(); g < b.length; g++) xn((x = b[g]).obsSet, u.mutatedParts) && (je(O, x), x.subscribers.forEach(function(K) {
                      return f.add(K);
                    }));
                    else if (0 < y.length) {
                      l.optimisticOps = l.optimisticOps.filter(function(K) {
                        return K.trans !== u;
                      });
                      for (var w = 0, _ = Object.values(l.queries.query); w < _.length; w++) for (var O, x, k, j = 0, P = (O = _[w]).slice(); j < P.length; j++) (x = P[j]).res != null && u.mutatedParts && (c && !x.dirty ? (k = Object.isFrozen(x.res), k = gr(x.res, x.req, y, d, x, k), x.dirty ? (je(O, x), x.subscribers.forEach(function(K) {
                        return f.add(K);
                      })) : k !== x.res && (x.res = k, x.promise = E.resolve({ result: k }))) : (x.dirty && je(O, x), x.subscribers.forEach(function(K) {
                        return f.add(K);
                      })));
                    }
                  }
                }
                f.forEach(function(K) {
                  return K();
                });
              }
            };
          }, u.addEventListener("abort", i(!1), { signal: a }), u.addEventListener("error", i(!1), { signal: a }), u.addEventListener("complete", i(!0), { signal: a })), u;
        }, table: function(n) {
          var r = e.table(n), i = r.schema.primaryKey;
          return D(D({}, r), { mutate: function(o) {
            var a = C.trans;
            if (i.outbound || a.db._options.cache === "disabled" || a.explicit || a.idbtrans.mode !== "readwrite") return r.mutate(o);
            var u = qe["idb://".concat(t, "/").concat(n)];
            return u ? (a = r.mutate(o), o.type !== "add" && o.type !== "put" || !(50 <= o.values.length || Kn(i, o).some(function(c) {
              return c == null;
            })) ? (u.optimisticOps.push(o), o.mutatedParts && Rt(o.mutatedParts), a.then(function(c) {
              0 < c.numFailures && (je(u.optimisticOps, o), (c = mr(0, o, c)) && u.optimisticOps.push(c), o.mutatedParts && Rt(o.mutatedParts));
            }), a.catch(function() {
              je(u.optimisticOps, o), o.mutatedParts && Rt(o.mutatedParts);
            })) : a.then(function(c) {
              var f = mr(0, D(D({}, o), { values: o.values.map(function(p, s) {
                var v;
                return c.failures[s] ? p : (p = (v = i.keyPath) !== null && v !== void 0 && v.includes(".") ? Oe(p) : D({}, p), ie(p, i.keyPath, c.results[s]), p);
              }) }), c);
              u.optimisticOps.push(f), queueMicrotask(function() {
                return o.mutatedParts && Rt(o.mutatedParts);
              });
            }), a) : r.mutate(o);
          }, query: function(o) {
            if (!yr(C, r) || !vr("query", o)) return r.query(o);
            var a = ((f = C.trans) === null || f === void 0 ? void 0 : f.db._options.cache) === "immutable", s = C, u = s.requery, c = s.signal, f = function(d, y, h, m) {
              var g = qe["idb://".concat(d, "/").concat(y)];
              if (!g) return [];
              if (!(y = g.queries[h])) return [null, !1, g, null];
              var b = y[(m.query ? m.query.index.name : null) || ""];
              if (!b) return [null, !1, g, null];
              switch (h) {
                case "query":
                  var w = b.find(function(_) {
                    return _.req.limit === m.limit && _.req.values === m.values && br(_.req.query.range, m.query.range);
                  });
                  return w ? [w, !0, g, b] : [b.find(function(_) {
                    return ("limit" in _.req ? _.req.limit : 1 / 0) >= m.limit && (!m.values || _.req.values) && ii(_.req.query.range, m.query.range);
                  }), !1, g, b];
                case "count":
                  return w = b.find(function(_) {
                    return br(_.req.query.range, m.query.range);
                  }), [w, !!w, g, b];
              }
            }(t, n, "query", o), p = f[0], s = f[1], v = f[2], l = f[3];
            return p && s ? p.obsSet = o.obsSet : (s = r.query(o).then(function(d) {
              var y = d.result;
              if (p && (p.res = y), a) {
                for (var h = 0, m = y.length; h < m; ++h) Object.freeze(y[h]);
                Object.freeze(y);
              } else d.result = Oe(y);
              return d;
            }).catch(function(d) {
              return l && p && je(l, p), Promise.reject(d);
            }), p = { obsSet: o.obsSet, promise: s, subscribers: /* @__PURE__ */ new Set(), type: "query", req: o, dirty: !1 }, l ? l.push(p) : (l = [p], (v = v || (qe["idb://".concat(t, "/").concat(n)] = { queries: { query: {}, count: {} }, objs: /* @__PURE__ */ new Map(), optimisticOps: [], unsignaledParts: {} })).queries.query[o.query.index.name || ""] = l)), oi(p, l, u, c), p.promise.then(function(d) {
              return { result: gr(d.result, o, v == null ? void 0 : v.optimisticOps, r, p, a) };
            });
          } });
        } });
      } };
      function Mt(e, t) {
        return new Proxy(e, { get: function(n, r, i) {
          return r === "db" ? t : Reflect.get(n, r, i);
        } });
      }
      var ye = ($.prototype.version = function(e) {
        if (isNaN(e) || e < 0.1) throw new T.Type("Given version is not a positive number");
        if (e = Math.round(10 * e) / 10, this.idbdb || this._state.isBeingOpened) throw new T.Schema("Cannot add version when database is open");
        this.verno = Math.max(this.verno, e);
        var t = this._versions, n = t.filter(function(r) {
          return r._cfg.version === e;
        })[0];
        return n || (n = new this.Version(e), t.push(n), t.sort(Gr), n.stores({}), this._state.autoSchema = !1, n);
      }, $.prototype._whenReady = function(e) {
        var t = this;
        return this.idbdb && (this._state.openComplete || C.letThrough || this._vip) ? e() : new E(function(n, r) {
          if (t._state.openComplete) return r(new T.DatabaseClosed(t._state.dbOpenError));
          if (!t._state.isBeingOpened) {
            if (!t._state.autoOpen) return void r(new T.DatabaseClosed());
            t.open().catch(U);
          }
          t._state.dbReadyPromise.then(n, r);
        }).then(e);
      }, $.prototype.use = function(e) {
        var t = e.stack, n = e.create, r = e.level, i = e.name;
        return i && this.unuse({ stack: t, name: i }), e = this._middlewares[t] || (this._middlewares[t] = []), e.push({ stack: t, create: n, level: r ?? 10, name: i }), e.sort(function(o, a) {
          return o.level - a.level;
        }), this;
      }, $.prototype.unuse = function(e) {
        var t = e.stack, n = e.name, r = e.create;
        return t && this._middlewares[t] && (this._middlewares[t] = this._middlewares[t].filter(function(i) {
          return r ? i.create !== r : !!n && i.name !== n;
        })), this;
      }, $.prototype.open = function() {
        var e = this;
        return Ie(me, function() {
          return Zr(e);
        });
      }, $.prototype._close = function() {
        var e = this._state, t = Ye.indexOf(this);
        if (0 <= t && Ye.splice(t, 1), this.idbdb) {
          try {
            this.idbdb.close();
          } catch {
          }
          this.idbdb = null;
        }
        e.isBeingOpened || (e.dbReadyPromise = new E(function(n) {
          e.dbReadyResolve = n;
        }), e.openCanceller = new E(function(n, r) {
          e.cancelOpen = r;
        }));
      }, $.prototype.close = function(n) {
        var t = (n === void 0 ? { disableAutoOpen: !0 } : n).disableAutoOpen, n = this._state;
        t ? (n.isBeingOpened && n.cancelOpen(new T.DatabaseClosed()), this._close(), n.autoOpen = !1, n.dbOpenError = new T.DatabaseClosed()) : (this._close(), n.autoOpen = this._options.autoOpen || n.isBeingOpened, n.openComplete = !1, n.dbOpenError = null);
      }, $.prototype.delete = function(e) {
        var t = this;
        e === void 0 && (e = { disableAutoOpen: !0 });
        var n = 0 < arguments.length && typeof arguments[0] != "object", r = this._state;
        return new E(function(i, o) {
          function a() {
            t.close(e);
            var u = t._deps.indexedDB.deleteDatabase(t.name);
            u.onsuccess = W(function() {
              var c, f, p;
              c = t._deps, f = t.name, p = c.indexedDB, c = c.IDBKeyRange, bn(p) || f === Pt || gn(p, c).delete(f).catch(U), i();
            }), u.onerror = le(o), u.onblocked = t._fireOnBlocked;
          }
          if (n) throw new T.InvalidArgument("Invalid closeOptions argument to db.delete()");
          r.isBeingOpened ? r.dbReadyPromise.then(a) : a();
        });
      }, $.prototype.backendDB = function() {
        return this.idbdb;
      }, $.prototype.isOpen = function() {
        return this.idbdb !== null;
      }, $.prototype.hasBeenClosed = function() {
        var e = this._state.dbOpenError;
        return e && e.name === "DatabaseClosed";
      }, $.prototype.hasFailed = function() {
        return this._state.dbOpenError !== null;
      }, $.prototype.dynamicallyOpened = function() {
        return this._state.autoSchema;
      }, Object.defineProperty($.prototype, "tables", { get: function() {
        var e = this;
        return q(this._allTables).map(function(t) {
          return e._allTables[t];
        });
      }, enumerable: !1, configurable: !0 }), $.prototype.transaction = function() {
        var e = (function(t, n, r) {
          var i = arguments.length;
          if (i < 2) throw new T.InvalidArgument("Too few arguments");
          for (var o = new Array(i - 1); --i; ) o[i - 1] = arguments[i];
          return r = o.pop(), [t, Mn(o), r];
        }).apply(this, arguments);
        return this._transaction.apply(this, e);
      }, $.prototype._transaction = function(e, t, n) {
        var r = this, i = C.trans;
        i && i.db === this && e.indexOf("!") === -1 || (i = null);
        var o, a, u = e.indexOf("?") !== -1;
        e = e.replace("!", "").replace("?", "");
        try {
          if (a = t.map(function(f) {
            if (f = f instanceof r.Table ? f.name : f, typeof f != "string") throw new TypeError("Invalid table argument to Dexie.transaction(). Only Table or String are allowed");
            return f;
          }), e == "r" || e === an) o = an;
          else {
            if (e != "rw" && e != un) throw new T.InvalidArgument("Invalid transaction mode: " + e);
            o = un;
          }
          if (i) {
            if (i.mode === an && o === un) {
              if (!u) throw new T.SubTransaction("Cannot enter a sub-transaction with READWRITE mode when parent transaction is READONLY");
              i = null;
            }
            i && a.forEach(function(f) {
              if (i && i.storeNames.indexOf(f) === -1) {
                if (!u) throw new T.SubTransaction("Table " + f + " not included in parent transaction.");
                i = null;
              }
            }), u && i && !i.active && (i = null);
          }
        } catch (f) {
          return i ? i._promise(null, function(p, s) {
            s(f);
          }) : Y(f);
        }
        var c = (function f(p, s, v, l, d) {
          return E.resolve().then(function() {
            var y = C.transless || C, h = p._createTransaction(s, v, p._dbSchema, l);
            if (h.explicit = !0, y = { trans: h, transless: y }, l) h.idbtrans = l.idbtrans;
            else try {
              h.create(), h.idbtrans._explicit = !0, p._state.PR1398_maxLoop = 3;
            } catch (b) {
              return b.name === Gt.InvalidState && p.isOpen() && 0 < --p._state.PR1398_maxLoop ? (console.warn("Dexie: Need to reopen db"), p.close({ disableAutoOpen: !1 }), p.open().then(function() {
                return f(p, s, v, null, d);
              })) : Y(b);
            }
            var m, g = Qt(d);
            return g && We(), y = E.follow(function() {
              var b;
              (m = d.call(h, h)) && (g ? (b = be.bind(null, null), m.then(b, b)) : typeof m.next == "function" && typeof m.throw == "function" && (m = jn(m)));
            }, y), (m && typeof m.then == "function" ? E.resolve(m).then(function(b) {
              return h.active ? b : Y(new T.PrematureCommit("Transaction committed too early. See http://bit.ly/2kdckMn"));
            }) : y.then(function() {
              return m;
            })).then(function(b) {
              return l && h._resolve(), h._completion.then(function() {
                return b;
              });
            }).catch(function(b) {
              return h._reject(b), Y(b);
            });
          });
        }).bind(null, this, o, a, i, n);
        return i ? i._promise(o, c, "lock") : C.trans ? Ie(C.transless, function() {
          return r._whenReady(c);
        }) : this._whenReady(c);
      }, $.prototype.table = function(e) {
        if (!re(this._allTables, e)) throw new T.InvalidTable("Table ".concat(e, " does not exist"));
        return this._allTables[e];
      }, $);
      function $(e, t) {
        var n = this;
        this._middlewares = {}, this.verno = 0;
        var r = $.dependencies;
        this._options = t = D({ addons: $.addons, autoOpen: !0, indexedDB: r.indexedDB, IDBKeyRange: r.IDBKeyRange, cache: "cloned" }, t), this._deps = { indexedDB: t.indexedDB, IDBKeyRange: t.IDBKeyRange }, r = t.addons, this._dbSchema = {}, this._versions = [], this._storeNames = [], this._allTables = {}, this.idbdb = null, this._novip = this;
        var i, o, a, u, c, f = { dbOpenError: null, isBeingOpened: !1, onReadyBeingFired: null, openComplete: !1, dbReadyResolve: U, dbReadyPromise: null, cancelOpen: U, openCanceller: null, autoSchema: !0, PR1398_maxLoop: 3, autoOpen: t.autoOpen };
        f.dbReadyPromise = new E(function(s) {
          f.dbReadyResolve = s;
        }), f.openCanceller = new E(function(s, v) {
          f.cancelOpen = v;
        }), this._state = f, this.name = e, this.on = rt(this, "populate", "blocked", "versionchange", "close", { ready: [Xt, U] }), this.on.ready.subscribe = Bn(this.on.ready.subscribe, function(s) {
          return function(v, l) {
            $.vip(function() {
              var d, y = n._state;
              y.openComplete ? (y.dbOpenError || E.resolve().then(v), l && s(v)) : y.onReadyBeingFired ? (y.onReadyBeingFired.push(v), l && s(v)) : (s(v), d = n, l || s(function h() {
                d.on.ready.unsubscribe(v), d.on.ready.unsubscribe(h);
              }));
            });
          };
        }), this.Collection = (i = this, it(Ur.prototype, function(m, h) {
          this.db = i;
          var l = Xn, d = null;
          if (h) try {
            l = h();
          } catch (g) {
            d = g;
          }
          var y = m._ctx, h = y.table, m = h.hook.reading.fire;
          this._ctx = { table: h, index: y.index, isPrimKey: !y.index || h.schema.primKey.keyPath && y.index === h.schema.primKey.name, range: l, keysOnly: !1, dir: "next", unique: "", algorithm: null, filter: null, replayFilter: null, justLimit: !0, isMatch: null, offset: 0, limit: 1 / 0, error: d, or: y.or, valueMapper: m !== Je ? m : null };
        })), this.Table = (o = this, it(er.prototype, function(s, v, l) {
          this.db = o, this._tx = l, this.name = s, this.schema = v, this.hook = o._allTables[s] ? o._allTables[s].hook : rt(null, { creating: [Tr, U], reading: [Ir, Je], updating: [qr, U], deleting: [Dr, U] });
        })), this.Transaction = (a = this, it(Wr.prototype, function(s, v, l, d, y) {
          var h = this;
          this.db = a, this.mode = s, this.storeNames = v, this.schema = l, this.chromeTransactionDurability = d, this.idbtrans = null, this.on = rt(this, "complete", "error", "abort"), this.parent = y || null, this.active = !0, this._reculock = 0, this._blockedFuncs = [], this._resolve = null, this._reject = null, this._waitingFor = null, this._waitingQueue = null, this._spinCount = 0, this._completion = new E(function(m, g) {
            h._resolve = m, h._reject = g;
          }), this._completion.then(function() {
            h.active = !1, h.on.complete.fire();
          }, function(m) {
            var g = h.active;
            return h.active = !1, h.on.error.fire(m), h.parent ? h.parent._reject(m) : g && h.idbtrans && h.idbtrans.abort(), Y(m);
          });
        })), this.Version = (u = this, it(Jr.prototype, function(s) {
          this.db = u, this._cfg = { version: s, storesSource: null, dbschema: {}, tables: {}, contentUpgrade: null };
        })), this.WhereClause = (c = this, it(or.prototype, function(s, v, l) {
          if (this.db = c, this._ctx = { table: s, index: v === ":id" ? null : v, or: l }, this._cmp = this._ascending = N, this._descending = function(d, y) {
            return N(y, d);
          }, this._max = function(d, y) {
            return 0 < N(d, y) ? d : y;
          }, this._min = function(d, y) {
            return N(d, y) < 0 ? d : y;
          }, this._IDBKeyRange = c._deps.IDBKeyRange, !this._IDBKeyRange) throw new T.MissingAPI();
        })), this.on("versionchange", function(s) {
          0 < s.newVersion ? console.warn("Another connection wants to upgrade database '".concat(n.name, "'. Closing db now to resume the upgrade.")) : console.warn("Another connection wants to delete database '".concat(n.name, "'. Closing db now to resume the delete request.")), n.close({ disableAutoOpen: !1 });
        }), this.on("blocked", function(s) {
          !s.newVersion || s.newVersion < s.oldVersion ? console.warn("Dexie.delete('".concat(n.name, "') was blocked")) : console.warn("Upgrade '".concat(n.name, "' blocked by other connection holding version ").concat(s.oldVersion / 10));
        }), this._maxKey = st(t.IDBKeyRange), this._createTransaction = function(s, v, l, d) {
          return new n.Transaction(s, v, l, n._options.chromeTransactionDurability, d);
        }, this._fireOnBlocked = function(s) {
          n.on("blocked").fire(s), Ye.filter(function(v) {
            return v.name === n.name && v !== n && !v._state.vcFired;
          }).map(function(v) {
            return v.on("versionchange").fire(s);
          });
        }, this.use(ni), this.use(ai), this.use(ri), this.use(ei), this.use(ti);
        var p = new Proxy(this, { get: function(s, v, l) {
          if (v === "_vip") return !0;
          if (v === "table") return function(y) {
            return Mt(n.table(y), p);
          };
          var d = Reflect.get(s, v, l);
          return d instanceof er ? Mt(d, p) : v === "tables" ? d.map(function(y) {
            return Mt(y, p);
          }) : v === "_createTransaction" ? function() {
            return Mt(d.apply(this, arguments), p);
          } : d;
        } });
        this.vip = p, r.forEach(function(s) {
          return s(n);
        });
      }
      var Nt, se = typeof Symbol < "u" && "observable" in Symbol ? Symbol.observable : "@@observable", ui = (An.prototype.subscribe = function(e, t, n) {
        return this._subscribe(e && typeof e != "function" ? e : { next: e, error: t, complete: n });
      }, An.prototype[se] = function() {
        return this;
      }, An);
      function An(e) {
        this._subscribe = e;
      }
      try {
        Nt = { indexedDB: Q.indexedDB || Q.mozIndexedDB || Q.webkitIndexedDB || Q.msIndexedDB, IDBKeyRange: Q.IDBKeyRange || Q.webkitIDBKeyRange };
      } catch {
        Nt = { indexedDB: null, IDBKeyRange: null };
      }
      function wr(e) {
        var t, n = !1, r = new ui(function(i) {
          var o = Qt(e), a, u = !1, c = {}, f = {}, p = { get closed() {
            return u;
          }, unsubscribe: function() {
            u || (u = !0, a && a.abort(), s && xe.storagemutated.unsubscribe(l));
          } };
          i.start && i.start(p);
          var s = !1, v = function() {
            return on(d);
          }, l = function(y) {
            Bt(c, y), xn(f, c) && v();
          }, d = function() {
            var y, h, m;
            !u && Nt.indexedDB && (c = {}, y = {}, a && a.abort(), a = new AbortController(), m = function(g) {
              var b = Ve();
              try {
                o && We();
                var w = ge(e, g);
                return w = o ? w.finally(be) : w;
              } finally {
                b && ze();
              }
            }(h = { subscr: y, signal: a.signal, requery: v, querier: e, trans: null }), Promise.resolve(m).then(function(g) {
              n = !0, t = g, u || h.signal.aborted || (c = {}, function(b) {
                for (var w in b) if (re(b, w)) return;
                return 1;
              }(f = y) || s || (xe(ut, l), s = !0), on(function() {
                return !u && i.next && i.next(g);
              }));
            }, function(g) {
              n = !1, ["DatabaseClosedError", "AbortError"].includes(g == null ? void 0 : g.name) || u || on(function() {
                u || i.error && i.error(g);
              });
            }));
          };
          return setTimeout(v, 0), p;
        });
        return r.hasValue = function() {
          return n;
        }, r.getValue = function() {
          return t;
        }, r;
      }
      var Be = ye;
      function Cn(e) {
        var t = ke;
        try {
          ke = !0, xe.storagemutated.fire(e), On(e, !0);
        } finally {
          ke = t;
        }
      }
      Fe(Be, D(D({}, yt), { delete: function(e) {
        return new Be(e, { addons: [] }).delete();
      }, exists: function(e) {
        return new Be(e, { addons: [] }).open().then(function(t) {
          return t.close(), !0;
        }).catch("NoSuchDatabaseError", function() {
          return !1;
        });
      }, getDatabaseNames: function(e) {
        try {
          return t = Be.dependencies, n = t.indexedDB, t = t.IDBKeyRange, (bn(n) ? Promise.resolve(n.databases()).then(function(r) {
            return r.map(function(i) {
              return i.name;
            }).filter(function(i) {
              return i !== Pt;
            });
          }) : gn(n, t).toCollection().primaryKeys()).then(e);
        } catch {
          return Y(new T.MissingAPI());
        }
        var t, n;
      }, defineClass: function() {
        return function(e) {
          V(this, e);
        };
      }, ignoreTransaction: function(e) {
        return C.trans ? Ie(C.transless, e) : e();
      }, vip: wn, async: function(e) {
        return function() {
          try {
            var t = jn(e.apply(this, arguments));
            return t && typeof t.then == "function" ? t : E.resolve(t);
          } catch (n) {
            return Y(n);
          }
        };
      }, spawn: function(e, t, n) {
        try {
          var r = jn(e.apply(n, t || []));
          return r && typeof r.then == "function" ? r : E.resolve(r);
        } catch (i) {
          return Y(i);
        }
      }, currentTransaction: { get: function() {
        return C.trans || null;
      } }, waitFor: function(e, t) {
        return t = E.resolve(typeof e == "function" ? Be.ignoreTransaction(e) : e).timeout(t || 6e4), C.trans ? C.trans.waitFor(t) : t;
      }, Promise: E, debug: { get: function() {
        return ce;
      }, set: function(e) {
        Vn(e);
      } }, derive: Me, extend: V, props: Fe, override: Bn, Events: rt, on: xe, liveQuery: wr, extendObservabilitySet: Bt, getByKeyPath: he, setByKeyPath: ie, delByKeyPath: function(e, t) {
        typeof t == "string" ? ie(e, t, void 0) : "length" in t && [].map.call(t, function(n) {
          ie(e, n, void 0);
        });
      }, shallowClone: Fn, deepClone: Oe, getObjectDiff: En, cmp: N, asap: Rn, minKey: -1 / 0, addons: [], connections: Ye, errnames: Gt, dependencies: Nt, cache: qe, semVer: "4.0.11", version: "4.0.11".split(".").map(function(e) {
        return parseInt(e);
      }).reduce(function(e, t, n) {
        return e + t / Math.pow(10, 2 * n);
      }) })), Be.maxKey = st(Be.dependencies.IDBKeyRange), typeof dispatchEvent < "u" && typeof addEventListener < "u" && (xe(ut, function(e) {
        ke || (e = new CustomEvent(fn, { detail: e }), ke = !0, dispatchEvent(e), ke = !1);
      }), addEventListener(fn, function(e) {
        e = e.detail, ke || Cn(e);
      }));
      var Ge, ke = !1, _r = function() {
      };
      return typeof BroadcastChannel < "u" && ((_r = function() {
        (Ge = new BroadcastChannel(fn)).onmessage = function(e) {
          return e.data && Cn(e.data);
        };
      })(), typeof Ge.unref == "function" && Ge.unref(), xe(ut, function(e) {
        ke || Ge.postMessage(e);
      })), typeof addEventListener < "u" && (addEventListener("pagehide", function(e) {
        if (!ye.disableBfCache && e.persisted) {
          ce && console.debug("Dexie: handling persisted pagehide"), Ge != null && Ge.close();
          for (var t = 0, n = Ye; t < n.length; t++) n[t].close({ disableAutoOpen: !1 });
        }
      }), addEventListener("pageshow", function(e) {
        !ye.disableBfCache && e.persisted && (ce && console.debug("Dexie: handling persisted pageshow"), _r(), Cn({ all: new Z(-1 / 0, [[]]) }));
      })), E.rejectionMapper = function(e, t) {
        return !e || e instanceof Le || e instanceof TypeError || e instanceof SyntaxError || !e.name || !Un[e.name] ? e : (t = new Un[e.name](t || e.message, e), "stack" in e && ve(t, "stack", { get: function() {
          return this.inner.stack;
        } }), t);
      }, Vn(ce), D(ye, Object.freeze({ __proto__: null, Dexie: ye, liveQuery: wr, Entity: Hn, cmp: N, PropModification: ot, replacePrefix: function(e, t) {
        return new ot({ replacePrefix: [e, t] });
      }, add: function(e) {
        return new ot({ add: e });
      }, remove: function(e) {
        return new ot({ remove: e });
      }, default: ye, RangeSet: Z, mergeRanges: ft, rangesOverlap: lr }), { default: ye }), ye;
    });
  }(Ut)), Ut.exports;
}
var pi = di();
const Dn = /* @__PURE__ */ fi(pi), kr = Symbol.for("Dexie"), Vt = globalThis[kr] || (globalThis[kr] = Dn);
if (Dn.semVer !== Vt.semVer)
  throw new Error(`Two different versions of Dexie loaded in the same app: ${Dn.semVer} and ${Vt.semVer}`);
const {
  liveQuery: gi,
  mergeRanges: bi,
  rangesOverlap: wi,
  RangeSet: _i,
  cmp: xi,
  Entity: ki,
  PropModification: Pi,
  replacePrefix: Oi,
  add: ji,
  remove: Ei
} = Vt;
class yi extends Vt {
  constructor() {
    super("ProjectDatabase");
    Tn(this, "projects");
    Tn(this, "testRuns");
    this.version(1).stores({
      projects: "++id, name, description, target_url, status, created_date, updated_date, recorded_steps, parsed_fields, csv_data",
      testRuns: "++id, project_id, status, start_time, end_time, total_steps, passed_steps, failed_steps"
    });
  }
  async addProject(I) {
    return await this.projects.add(I);
  }
  async updateProject(I, D) {
    return await this.projects.update(I, D);
  }
  async getAllProjects() {
    return await this.projects.toArray();
  }
  async deleteProject(I) {
    return await this.projects.delete(I);
  }
  // TestRun methods
  async createTestRun(I) {
    return await this.testRuns.add(I);
  }
  async updateTestRun(I, D) {
    return await this.testRuns.update(I, D);
  }
  async getTestRunsByProject(I) {
    return await this.testRuns.where("project_id").equals(I).reverse().sortBy("start_time");
  }
}
const ue = new yi();
async function vi() {
  if ("storage" in navigator && navigator.storage && navigator.storage.persist) {
    const S = await navigator.storage.persisted();
    if (console.log("Storage persisted?", S), !S) {
      const G = await navigator.storage.persist();
      console.log("Persistence granted:", G);
    }
  } else
    console.warn("navigator.storage.persist not available in this context");
}
vi();
let ht = null;
const zt = /* @__PURE__ */ new Set();
chrome.runtime.onMessage.addListener((S, G, I) => {
  var D, Pe, Q;
  if (!S.action) return !1;
  try {
    if (S.action === "add_project") {
      const q = {
        ...S.payload,
        recorded_steps: [],
        parsed_fields: [],
        csv_data: []
      };
      return ue.addProject(q).then((A) => I({ success: !0, id: A })).catch((A) => I({ success: !1, error: A.message })), !0;
    }
    if (S.action === "update_project")
      return ue.updateProject(S.payload.id, {
        name: S.payload.name,
        description: S.payload.description,
        target_url: S.payload.target_url
      }).then(() => I({ success: !0 })).catch(
        (q) => I({ success: !1, error: q.message })
      ), !0;
    if (S.action === "get_all_projects")
      return ue.getAllProjects().then((q) => I({ success: !0, projects: q })).catch((q) => I({ success: !1, error: q.message })), !0;
    if (S.action === "delete_project") {
      const q = (D = S.payload) == null ? void 0 : D.projectId;
      return ue.deleteProject(q).then(() => I({ success: !0 })).catch((A) => I({ success: !1, error: A.message })), !0;
    }
    if (S.action === "get_project_by_id") {
      const q = (Pe = S.payload) == null ? void 0 : Pe.id;
      return ue.projects.get(q).then((A) => {
        I(A ? { success: !0, project: A } : { success: !1, error: "Process  not found" });
      }).catch((A) => {
        I({ success: !1, error: A.message });
      }), !0;
    }
    if (S.action === "open_project_url_and_inject") {
      const q = (Q = S.payload) == null ? void 0 : Q.id;
      return ue.getAllProjects().then((A) => {
        const V = A.find((J) => J.id === q);
        if (!V || !V.target_url) {
          I({ success: !1, error: "Process not found or missing URL" });
          return;
        }
        chrome.tabs.create({ url: V.target_url }, (J) => {
          J != null && J.id && (ht = J.id, zt.add(J.id), Wt(J.id));
        });
      }).catch((A) => {
        I({ success: !1, error: A.message });
      }), !0;
    }
    if (S.action === "update_project_steps") {
      const { id: q, recorded_steps: A } = S.payload;
      return ue.projects.update(q, { recorded_steps: A }).then(() => {
        I({ success: !0 });
      }).catch((V) => {
        I({ success: !1, error: V.message });
      }), !0;
    }
    if (S.action === "update_project_fields") {
      const { id: q, parsed_fields: A, status: V } = S.payload;
      return ue.projects.update(q, { parsed_fields: A, status: V }).then(() => {
        I({ success: !0 });
      }).catch((J) => {
        I({ success: !1, error: J.message });
      }), !0;
    }
    if (S.action === "update_project_csv") {
      const { id: q, csv_data: A } = S.payload;
      return ue.projects.update(q, { csv_data: A }).then(() => {
        I({ success: !0 });
      }).catch((V) => {
        I({ success: !1, error: V.message });
      }), !0;
    }
    if (S.action === "createTestRun")
      return (async () => {
        try {
          const q = await ue.testRuns.add(S.payload), A = await ue.testRuns.get(q);
          I({ success: !0, testRun: A });
        } catch (q) {
          I({ success: !1, error: q });
        }
      })(), !0;
    if (S.action === "updateTestRun")
      return (async () => {
        try {
          await ue.testRuns.update(S.id, S.payload), I({ success: !0 });
        } catch (q) {
          I({ success: !1, error: q });
        }
      })(), !0;
    if (S.action === "getTestRunsByProject") {
      const q = S.projectId;
      return ue.getTestRunsByProject(q).then((A) => {
        I({ success: !0, data: A });
      }).catch((A) => {
        I({ success: !1, error: A.message });
      }), !0;
    }
    if (S.action === "openTab") {
      const q = S.url;
      return chrome.tabs.create({ url: q }, (A) => {
        if (chrome.runtime.lastError) {
          console.error("Failed to create tab:", chrome.runtime.lastError.message), I({ success: !1, error: chrome.runtime.lastError.message });
          return;
        }
        if (!(A != null && A.id)) {
          I({ success: !1, error: "No tab ID returned" });
          return;
        }
        Wt(A.id, (V) => {
          V.success ? (console.log("Injected into tab", A.id), A != null && A.id && (ht = A.id, zt.add(A.id), I({ success: !0, tabId: A.id }))) : (console.error("Injection failed:", V.error), I({ success: !1, error: V.error }));
        });
      }), !0;
    }
    if (S.action === "close_opened_tab")
      return ht !== null ? chrome.tabs.remove(ht, () => {
        ht = null, I({ success: !0 });
      }) : I({ success: !1, error: "No opened tab to close" }), !0;
    if (S.action === "openDashBoard")
      return chrome.tabs.create({ url: chrome.runtime.getURL("pages.html") }, () => {
        I({ success: !0 });
      }), !0;
  } catch (q) {
    return I({ success: !1, error: q.message }), !1;
  }
});
chrome.action.onClicked.addListener(() => {
  chrome.tabs.create({
    url: chrome.runtime.getURL("pages.html")
  });
});
chrome.runtime.onInstalled.addListener((S) => {
  S.reason === "install" && chrome.tabs.create({
    url: chrome.runtime.getURL("pages.html#dashboard")
  });
});
function Wt(S, G) {
  chrome.scripting.executeScript(
    {
      target: { tabId: S, allFrames: !0 },
      files: ["js/main.js"]
    },
    () => {
      chrome.runtime.lastError ? (console.warn("Inject failed:", chrome.runtime.lastError.message), G == null || G({ success: !1 })) : (console.log("Injected main.js into tab", S), G == null || G({ success: !0 }));
    }
  );
}
chrome.webNavigation.onCommitted.addListener((S) => {
  zt.has(S.tabId) && (console.log("Frame navigated:", S.frameId, S.url), Wt(S.tabId));
});
chrome.webNavigation.onCompleted.addListener((S) => {
  zt.has(S.tabId) && Wt(S.tabId);
});
